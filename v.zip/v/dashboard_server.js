const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const os = require('os');
const phoneNormalizer = require('./utils/PhoneNormalizer');

/**
 * DashboardServer - Secure real-time ticket dashboard
 * OWASP Top 10 compliant, ISO 27001/27002 aligned
 */
class DashboardServer {
    constructor() {
        this.app = express();
        this.db = null;
        this.clients = [];
        this.lastBroadcastData = null;
        this.config = null;
        this.security = null;
        this.dataManager = null;

        // Login rate limiting
        this.loginAttempts = new Map();
        this.MAX_LOGIN_ATTEMPTS = 5;
        this.LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

        // CSRF tokens
        this.csrfTokens = new Map();

        // Session tokens
        this.sessions = new Map();
        this.SESSION_DURATION = 8 * 60 * 60 * 1000; // 8 hours

        // JWT secret
        this.jwtSecret = this.getOrCreateSecret();
    }

    getOrCreateSecret() {
        const secretPath = path.join(__dirname, '.jwt_secret');
        try {
            if (fs.existsSync(secretPath)) {
                return fs.readFileSync(secretPath, 'utf8').trim();
            }
        } catch (e) { }

        const secret = crypto.randomBytes(32).toString('hex');
        try {
            fs.writeFileSync(secretPath, secret, { mode: 0o600 });
        } catch (e) { }
        return secret;
    }

    /**
     * Start the dashboard server
     */
    start(db, port = 3000, config = null, dataManager = null) {
        this.db = db;
        this.config = config;
        this.dataManager = dataManager;

        // Trust proxy for proper IP detection behind reverse proxy
        this.app.set('trust proxy', true);

        // JSON body parser
        this.app.use(express.json({ limit: '10kb' }));
        this.app.use(express.urlencoded({ extended: false, limit: '10kb' }));

        // Security headers middleware (OWASP)
        this.app.use((req, res, next) => {
            res.setHeader('X-Content-Type-Options', 'nosniff');
            res.setHeader('X-Frame-Options', 'DENY');
            res.setHeader('X-XSS-Protection', '1; mode=block');
            res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
            res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
            res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
            res.setHeader('Content-Security-Policy',
                "default-src 'self'; " +
                "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; " +
                "style-src 'self' 'unsafe-inline'; " +
                "img-src 'self' data:; " +
                "connect-src 'self'"
            );
            next();
        });

        this.setupAuthRoutes();
        this.setupProtectedRoutes();

        this.app.listen(port, () => {
            console.log(`✅ Dashboard server running on http://localhost:${port}`);
            console.log(`🔐 Login at http://localhost:${port}/login.html`);
        });

        // DB file watcher
        try {
            const dbPath = this.db?.dbPath;
            if (dbPath && fs.existsSync(dbPath)) {
                fs.watchFile(dbPath, { interval: 1000 }, (curr, prev) => {
                    if (curr.mtimeMs !== prev.mtimeMs) {
                        this.broadcastUpdates();
                    }
                });
            }
        } catch (err) { }

        setInterval(() => this.broadcastUpdates(), 1000);
        setInterval(() => this.cleanupSessions(), 60000);
    }

    /**
     * Setup authentication routes (public)
     */
    setupAuthRoutes() {
        // Serve login page (public)
        this.app.get('/login.html', (req, res) => {
            res.sendFile(path.join(__dirname, 'public', 'login.html'));
        });

        // Root redirect
        this.app.get('/', (req, res) => {
            const token = req.headers.cookie?.match(/session=([^;]+)/)?.[1];
            if (this.verifySession(token)) {
                res.redirect('/tickets.html');
            } else {
                res.redirect('/login.html');
            }
        });

        // CSRF token endpoint
        this.app.get('/api/auth/csrf', (req, res) => {
            const sessionId = crypto.randomBytes(16).toString('hex');
            const token = crypto.randomBytes(32).toString('hex');
            this.csrfTokens.set(sessionId, { token, expires: Date.now() + 3600000 });

            res.cookie('csrf_session', sessionId, {
                httpOnly: true,
                secure: false, // Set to true in production with HTTPS
                sameSite: 'strict',
                maxAge: 3600000
            });
            res.json({ token });
        });

        // Check session endpoint
        this.app.get('/api/auth/check', (req, res) => {
            const token = req.headers.cookie?.match(/session=([^;]+)/)?.[1];
            const session = this.verifySession(token);
            res.json({ authenticated: !!session, phone: session?.phone });
        });

        // Login endpoint with rate limiting
        this.app.post('/api/auth/login', async (req, res) => {
            const ip = this.getClientIP(req);

            // Check rate limit
            const rateCheck = this.checkLoginRateLimit(ip);
            if (!rateCheck.allowed) {
                await this.logSecurityEvent('LOGIN_RATE_LIMITED', { ip });
                return res.status(429).json({
                    success: false,
                    message: 'Çox sayda cəhd. Gözləyin.',
                    retryAfter: rateCheck.lockoutRemaining
                });
            }

            // Verify CSRF
            const csrfSessionId = req.headers.cookie?.match(/csrf_session=([^;]+)/)?.[1];
            const csrfToken = req.headers['x-csrf-token'];
            if (!this.verifyCSRF(csrfSessionId, csrfToken)) {
                await this.logSecurityEvent('CSRF_FAILED', { ip });
                return res.status(403).json({ success: false, message: 'Təhlükəsizlik xətası' });
            }

            const { phone, password } = req.body;

            // Input validation
            if (!phone || !password) {
                return res.status(400).json({ success: false, message: 'Telefon və şifrə tələb olunur' });
            }

            const sanitizedPhone = this.sanitizePhone(phone);
            if (!sanitizedPhone) {
                return res.status(400).json({ success: false, message: 'Yanlış telefon formatı' });
            }

            // Check if admin exists
            const isAdmin = this.isAdmin(sanitizedPhone);
            if (!isAdmin) {
                this.recordFailedLogin(ip);
                await this.logSecurityEvent('LOGIN_NON_ADMIN', { ip, phone: sanitizedPhone });
                return res.status(401).json({ success: false, message: 'Yanlış telefon və ya şifrə' });
            }

            // Check password status
            const passwordStatus = await this.getPasswordStatus(sanitizedPhone);

            if (!passwordStatus.exists) {
                // No password set - need temp password from bot
                return res.status(401).json({
                    success: false,
                    message: 'Şifrə təyin edilməyib. Botdan /addadmin ilə əlavə edilərkən şifrə alacaqsınız.'
                });
            }

            // Verify password
            const passwordValid = await this.verifyPassword(password, passwordStatus.hash);
            if (!passwordValid) {
                this.recordFailedLogin(ip);
                await this.logSecurityEvent('LOGIN_WRONG_PASSWORD', { ip, phone: sanitizedPhone });
                return res.status(401).json({ success: false, message: 'Yanlış telefon və ya şifrə' });
            }

            // Check if password change required (temp password)
            if (passwordStatus.mustChange) {
                await this.logSecurityEvent('LOGIN_NEEDS_PASSWORD_CHANGE', { ip, phone: sanitizedPhone });
                return res.json({
                    success: true,
                    needsPasswordChange: true,
                    phone: sanitizedPhone,
                    message: 'Şifrənizi dəyişməlisiniz'
                });
            }

            // Create session
            this.clearFailedLogins(ip);
            const sessionToken = this.createSession(sanitizedPhone, ip, req.headers['user-agent']);

            await this.logSecurityEvent('LOGIN_SUCCESS', { ip, phone: sanitizedPhone });

            res.cookie('session', sessionToken, {
                httpOnly: true,
                secure: false,
                sameSite: 'lax', // Changed from strict for better redirect
                maxAge: this.SESSION_DURATION,
                path: '/'
            });

            res.json({ success: true, redirect: '/tickets.html' });
        });

        // Logout endpoint
        this.app.post('/api/auth/logout', (req, res) => {
            const token = req.headers.cookie?.match(/session=([^;]+)/)?.[1];
            if (token) {
                this.sessions.delete(token);
            }
            res.clearCookie('session');
            res.json({ success: true, redirect: '/login.html' });
        });

        // Password change endpoint (for temp password users)
        this.app.post('/api/auth/change-password', async (req, res) => {
            const { phone, currentPassword, newPassword, confirmPassword } = req.body;
            const ip = this.getClientIP(req);

            if (!phone || !currentPassword || !newPassword) {
                return res.status(400).json({ success: false, message: 'Bütün xanaları doldurun' });
            }

            if (newPassword !== confirmPassword) {
                return res.status(400).json({ success: false, message: 'Yeni şifrələr uyğun gəlmir' });
            }

            if (newPassword.length < 6) {
                return res.status(400).json({ success: false, message: 'Şifrə minimum 6 simvol olmalıdır' });
            }

            const sanitizedPhone = this.sanitizePhone(phone);
            const passwordStatus = await this.getPasswordStatus(sanitizedPhone);

            if (!passwordStatus.exists) {
                return res.status(400).json({ success: false, message: 'Hesab tapılmadı' });
            }

            // Verify current password
            const isValid = await this.verifyPassword(currentPassword, passwordStatus.hash);
            if (!isValid) {
                await this.logSecurityEvent('PASSWORD_CHANGE_WRONG_CURRENT', { ip, phone: sanitizedPhone });
                return res.status(401).json({ success: false, message: 'Cari şifrə yanlışdır' });
            }

            // Change password
            await this.changePassword(sanitizedPhone, newPassword);
            await this.logSecurityEvent('PASSWORD_CHANGED', { ip, phone: sanitizedPhone });

            // Create session
            const sessionToken = this.createSession(sanitizedPhone, ip, req.headers['user-agent']);

            res.cookie('session', sessionToken, {
                httpOnly: true,
                secure: false,
                sameSite: 'lax',
                maxAge: this.SESSION_DURATION,
                path: '/'
            });

            res.json({ success: true, redirect: '/tickets.html' });
        });

        // Set password endpoint (for admins setting up their account)
        this.app.post('/api/auth/setup-password', async (req, res) => {
            const { phone, password, confirmPassword } = req.body;

            if (!phone || !password || password !== confirmPassword) {
                return res.status(400).json({ success: false, message: 'Yanlış məlumat' });
            }

            const sanitizedPhone = this.sanitizePhone(phone);
            if (!this.isAdmin(sanitizedPhone)) {
                return res.status(403).json({ success: false, message: 'Admin deyil' });
            }

            // Check if password already set
            const existing = await this.db?.get('SELECT phone FROM admin_passwords WHERE phone = ?', [sanitizedPhone]);
            if (existing) {
                return res.status(400).json({ success: false, message: 'Şifrə artıq mövcuddur' });
            }

            // Hash and store password
            const hash = await this.hashPassword(password);
            await this.db?.run(
                'INSERT INTO admin_passwords (phone, password_hash) VALUES (?, ?)',
                [sanitizedPhone, hash]
            );

            await this.logSecurityEvent('PASSWORD_SETUP', { phone: sanitizedPhone });
            res.json({ success: true, message: 'Şifrə yaradıldı' });
        });
    }

    /**
     * Setup protected routes (require authentication)
     */
    setupProtectedRoutes() {
        // Authentication middleware for protected routes
        const authMiddleware = (req, res, next) => {
            const token = req.headers.cookie?.match(/session=([^;]+)/)?.[1];
            const session = this.verifySession(token);

            if (!session) {
                // Check if it's an API request or page request
                if (req.path.startsWith('/api/')) {
                    return res.status(401).json({ error: 'Unauthorized' });
                }
                return res.redirect('/login.html');
            }

            req.adminPhone = session.phone;
            next();
        };

        // Protect tickets.html
        this.app.get('/tickets.html', authMiddleware, (req, res) => {
            res.sendFile(path.join(__dirname, 'public', 'tickets.html'));
        });

        // Protect static files except login
        this.app.use((req, res, next) => {
            // Allow public files
            const publicPaths = ['/login.html', '/api/auth/', '/favicon.ico'];
            if (publicPaths.some(p => req.path.startsWith(p) || req.path === p)) {
                return next();
            }

            // Check session for other requests
            const token = req.headers.cookie?.match(/session=([^;]+)/)?.[1];
            if (!this.verifySession(token)) {
                if (req.path.endsWith('.html') || req.path === '/') {
                    return res.redirect('/login.html');
                }
                // For CSS/JS files, still serve them (needed for login page)
                if (req.path.endsWith('.css') || req.path.endsWith('.js')) {
                    return next();
                }
                return res.status(401).json({ error: 'Unauthorized' });
            }
            next();
        });

        // Serve static files
        this.app.use(express.static(path.join(__dirname, 'public')));

        // Protected API endpoints
        this.app.get('/api/stream', authMiddleware, (req, res) => {
            res.setHeader('Content-Type', 'text/event-stream');
            res.setHeader('Cache-Control', 'no-cache');
            res.setHeader('Connection', 'keep-alive');

            const clientId = Date.now();
            const newClient = { id: clientId, res };

            this.clients.push(newClient);
            this.sendDataToClient(newClient);

            req.on('close', () => {
                this.clients = this.clients.filter(c => c.id !== clientId);
            });
        });

        this.app.get('/api/stats', authMiddleware, async (req, res) => {
            try {
                const data = await this.getData();
                res.json(data);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.get('/api/ticket/:id/history', authMiddleware, async (req, res) => {
            try {
                const ticketId = parseInt(req.params.id);
                const history = await this.db?.all(
                    'SELECT * FROM ticket_history WHERE ticket_id = ? ORDER BY created_at DESC',
                    [ticketId]
                );
                res.json(history || []);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.get('/api/health', (req, res) => {
            res.json({
                status: 'ok',
                timestamp: Date.now(),
                clients: this.clients.length
            });
        });
    }

    // ============================================
    // SECURITY HELPERS
    // ============================================

    isAdmin(phone) {
        if (this.dataManager) {
            return this.dataManager.isAdmin(phone);
        }
        // Fallback: check admins.js file
        try {
            const adminsPath = path.join(__dirname, 'admins.js');
            delete require.cache[require.resolve(adminsPath)];
            const admins = require(adminsPath).admins || [];
            return admins.some(a => this.normalizePhone(a) === this.normalizePhone(phone));
        } catch (e) {
            return false;
        }
    }

    normalizePhone(phone) {
        return phoneNormalizer.normalize(phone);
    }

    sanitizePhone(phone) {
        if (!phone || typeof phone !== 'string') return null;
        const cleaned = phone.replace(/[^0-9+]/g, '').substring(0, 15);
        return this.normalizePhone(cleaned);
    }

    async hashPassword(password) {
        try {
            const bcrypt = require('bcrypt');
            return await bcrypt.hash(password, 12);
        } catch (e) {
            // Fallback
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
            return `${salt}:${hash}`;
        }
    }

    async verifyPassword(password, hash) {
        try {
            const bcrypt = require('bcrypt');
            return await bcrypt.compare(password, hash);
        } catch (e) {
            if (hash.includes(':')) {
                const [salt, storedHash] = hash.split(':');
                const testHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
                return storedHash === testHash;
            }
            return false;
        }
    }

    async getPasswordStatus(phone) {
        try {
            const record = await this.db?.get(
                'SELECT password_hash, must_change FROM admin_passwords WHERE phone = ?',
                [phone]
            );
            if (!record) {
                return { exists: false };
            }
            return {
                exists: true,
                hash: record.password_hash,
                mustChange: record.must_change === 1
            };
        } catch (e) {
            console.error('getPasswordStatus error:', e);
            return { exists: false };
        }
    }

    /**
     * Generate temp password for new admin (called by bot)
     */
    async generateTempPassword(phone) {
        const tempPass = crypto.randomBytes(4).toString('hex').toUpperCase(); // 8 char hex
        const hash = await this.hashPassword(tempPass);

        await this.db?.run(
            'INSERT OR REPLACE INTO admin_passwords (phone, password_hash, must_change, created_at, updated_at) VALUES (?, ?, 1, ?, ?)',
            [phone, hash, new Date().toISOString(), new Date().toISOString()]
        );

        return tempPass;
    }

    /**
     * Change password
     */
    async changePassword(phone, newPassword) {
        const hash = await this.hashPassword(newPassword);
        await this.db?.run(
            'UPDATE admin_passwords SET password_hash = ?, must_change = 0, updated_at = ? WHERE phone = ?',
            [hash, new Date().toISOString(), phone]
        );
    }

    createSession(phone, ip, userAgent) {
        const token = crypto.randomBytes(32).toString('hex');
        this.sessions.set(token, {
            phone,
            ip,
            userAgent,
            createdAt: Date.now(),
            expiresAt: Date.now() + this.SESSION_DURATION
        });
        return token;
    }

    verifySession(token) {
        if (!token) return null;
        const session = this.sessions.get(token);
        if (!session) return null;
        if (session.expiresAt < Date.now()) {
            this.sessions.delete(token);
            return null;
        }
        return session;
    }

    cleanupSessions() {
        const now = Date.now();
        for (const [token, session] of this.sessions.entries()) {
            if (session.expiresAt < now) {
                this.sessions.delete(token);
            }
        }
        // Cleanup CSRF tokens
        for (const [key, value] of this.csrfTokens.entries()) {
            if (value.expires < now) {
                this.csrfTokens.delete(key);
            }
        }
        // Cleanup login attempts
        for (const [key, value] of this.loginAttempts.entries()) {
            if (value.lockedUntil && value.lockedUntil < now - 3600000) {
                this.loginAttempts.delete(key);
            }
        }
    }

    verifyCSRF(sessionId, token) {
        if (!sessionId || !token) return false;
        const stored = this.csrfTokens.get(sessionId);
        if (!stored || stored.expires < Date.now()) {
            this.csrfTokens.delete(sessionId);
            return false;
        }
        return stored.token === token;
    }

    checkLoginRateLimit(identifier) {
        const record = this.loginAttempts.get(identifier);
        if (!record) {
            return { allowed: true, remainingAttempts: this.MAX_LOGIN_ATTEMPTS };
        }

        if (record.lockedUntil && record.lockedUntil > Date.now()) {
            return {
                allowed: false,
                lockoutRemaining: Math.ceil((record.lockedUntil - Date.now()) / 1000)
            };
        }

        if (record.lockedUntil && record.lockedUntil <= Date.now()) {
            this.loginAttempts.delete(identifier);
            return { allowed: true, remainingAttempts: this.MAX_LOGIN_ATTEMPTS };
        }

        return {
            allowed: record.attempts < this.MAX_LOGIN_ATTEMPTS,
            remainingAttempts: Math.max(0, this.MAX_LOGIN_ATTEMPTS - record.attempts)
        };
    }

    recordFailedLogin(identifier) {
        const record = this.loginAttempts.get(identifier) || { attempts: 0 };
        record.attempts++;
        record.lastAttempt = Date.now();

        if (record.attempts >= this.MAX_LOGIN_ATTEMPTS) {
            record.lockedUntil = Date.now() + this.LOCKOUT_DURATION;
        }

        this.loginAttempts.set(identifier, record);
    }

    clearFailedLogins(identifier) {
        this.loginAttempts.delete(identifier);
    }

    getClientIP(req) {
        let ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim()
            || req.connection?.remoteAddress
            || req.ip
            || 'unknown';

        // Strip IPv6 prefix from IPv4 addresses
        if (ip.startsWith('::ffff:')) {
            ip = ip.replace('::ffff:', '');
        }

        // For local access, show server's local network IP
        if (ip === '::1' || ip === '127.0.0.1' || ip === 'localhost') {
            ip = this.getServerLocalIP();
        }

        return ip;
    }

    /**
     * Get server's local network IP address
     */
    getServerLocalIP() {
        const interfaces = os.networkInterfaces();
        for (const name of Object.keys(interfaces)) {
            for (const iface of interfaces[name]) {
                // Skip internal and non-IPv4 addresses
                if (iface.family === 'IPv4' && !iface.internal) {
                    return iface.address;
                }
            }
        }
        return '127.0.0.1';
    }

    async logSecurityEvent(eventType, details = {}) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            type: eventType,
            ...details
        };
        console.log(`🔒 [SECURITY] ${eventType}:`, JSON.stringify(details));

        try {
            await this.db?.run(
                'INSERT INTO security_logs (event_type, details, ip_address, created_at) VALUES (?, ?, ?, ?)',
                [eventType, JSON.stringify(details), details.ip, new Date().toISOString()]
            );
        } catch (e) { }
    }

    // ============================================
    // DATA METHODS
    // ============================================

    async getData() {
        if (!this.db) return {};

        try {
            const openTickets = await this.db.all(
                "SELECT * FROM tickets WHERE status != 'solved' AND status != 'closed' ORDER BY priority DESC, id ASC"
            );
            const solvedTickets = await this.db.all(
                "SELECT * FROM tickets WHERE status = 'solved' OR status = 'closed' ORDER BY solved_at DESC"
            );

            // Use centralized phoneNormalizer instead of duplicated logic
            const normalizePhoneLocal = (phone) => phoneNormalizer.normalize(phone);

            const totalOpen = openTickets.length;
            const today = new Date().toISOString().split('T')[0];
            const todaySolved = await this.db.get(
                `SELECT COUNT(*) as count FROM tickets WHERE (status = 'solved' OR status = 'closed') AND solved_at LIKE '${today}%'`
            );

            const priorityCounts = {
                urgent: openTickets.filter(t => t.priority === 'urgent').length,
                high: openTickets.filter(t => t.priority === 'high').length,
                normal: openTickets.filter(t => !t.priority || t.priority === 'normal').length,
                low: openTickets.filter(t => t.priority === 'low').length
            };

            return {
                openTickets: openTickets.map(t => {
                    let assignedInfo = '---';
                    if (t.assigned_admin) {
                        assignedInfo = t.assigned_admin_name
                            ? `${t.assigned_admin_name} (${t.assigned_admin})`
                            : t.assigned_admin;
                    }

                    return {
                        id: t.id,
                        corpus: t.corpus,
                        room: t.room,
                        problem: t.problem || t.problem_type,
                        priority: t.priority || 'normal',
                        createdBy: t.opened_by || t.phone,
                        assignedTo: assignedInfo,
                        status: t.status,
                        createdAt: t.created_at,
                        created_at: t.created_at
                    };
                }),
                solvedTickets: solvedTickets.map(t => ({
                    id: t.id,
                    corpus: t.corpus,
                    room: t.room,
                    problem: t.problem || t.problem_type,
                    createdBy: t.opened_by || t.phone,
                    solvedBy: t.solved_by || 'Unknown',
                    solution: t.solution || '---',
                    solvedAt: t.solved_at
                })),
                stats: {
                    totalOpen,
                    todaySolved: todaySolved?.count || 0,
                    priorityCounts,
                    lastUpdate: new Date().toISOString()
                }
            };
        } catch (error) {
            console.error('getData error:', error);
            return {};
        }
    }

    async sendDataToClient(client) {
        const data = await this.getData();
        client.res.write(`data: ${JSON.stringify(data)}\n\n`);
    }

    async broadcastUpdates() {
        if (this.clients.length === 0) return;

        const data = await this.getData();
        const json = JSON.stringify(data);

        if (this.lastBroadcastData === json) return;
        this.lastBroadcastData = json;

        this.clients.forEach(client => {
            client.res.write(`data: ${json}\n\n`);
        });
    }
}

module.exports = new DashboardServer();
