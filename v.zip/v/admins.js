// ADMIN SİYAHISI
// Bu faylı dəyişdirməyin - DataManager avtomatik idarə edir

module.exports = {
    admins: [
        "994506799917",
        "994503078770",
        "994505228080"
],
    lastUpdated: "2025-12-12T14:07:07.155Z"
};
