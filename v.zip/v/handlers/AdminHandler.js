/**
 * AdminHandler - Handles admin-related commands
 * Ban/unban, admin management, login/logout
 */
const moment = require('moment');
const phoneNormalizer = require('../utils/PhoneNormalizer');

class AdminHandler {
    /**
     * @param {Object} bot - Reference to the main bot instance
     */
    constructor(bot) {
        this.bot = bot;
        this.db = bot.db;
        this.logger = bot.logger;
        this.client = bot.client;
        this.dataManager = bot.dataManager;
        this.configManager = bot.configManager;

        // Admin session tracking
        this.adminLoginState = bot.adminLoginState;
        this.adminSessions = bot.adminSessions;
        this.failedLoginAttempts = bot.failedLoginAttempts;
    }

    /**
     * Normalize phone number using centralized PhoneNormalizer
     * @param {string} phone - Phone to normalize
     * @returns {string|null}
     */
    normalizePhone(phone) {
        return phoneNormalizer.normalize(phone);
    }

    /**
     * Format phone number for display
     * @param {string} phone - Phone to format
     * @returns {string}
     */
    formatPhoneNumber(phone) {
        return this.bot.formatPhoneNumber(phone);
    }

    /**
     * Check if user has admin session or is persistent admin
     * @param {string} userId - User ID
     * @returns {boolean}
     */
    isAdmin(userId) {
        const normalizedSender = this.normalizePhone(userId);
        const isPersistentAdmin = this.dataManager.isAdmin(normalizedSender);
        const hasSession = this.adminSessions.has(userId);
        return hasSession || isPersistentAdmin;
    }

    /**
     * Handle /ban command
     * @param {Object} message - WhatsApp message
     */
    async handleBan(message) {
        const parts = message.body.split(' ');
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /ban <nömrə>');
            return;
        }

        try {
            const rawInput = parts[1];
            const normalized = this.normalizePhone(rawInput);

            if (!normalized) {
                await message.reply('❌ Nömrə düzgün formatda deyil!');
                return;
            }

            const existingBan = this.dataManager.isBanned(normalized);
            if (existingBan) {
                await message.reply(`ℹ️ ${this.formatPhoneNumber(normalized)} artıq banlanmışdı.`);
                return;
            }

            this.dataManager.banUser(normalized);
            await message.reply(`✅ ${this.formatPhoneNumber(normalized)} banlandı!`);

            this.logger.security('🔨 İstifadəçi banlandı:', { phoneNumber: normalized }, 'security');

        } catch (error) {
            this.logger.error('❌ Ban xətası:', error, 'security');
            await message.reply('❌ Ban edilərkən xəta baş verdi.');
        }
    }

    /**
     * Handle /unban command
     * @param {Object} message - WhatsApp message
     */
    async handleUnban(message) {
        const parts = message.body.split(' ');
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /unban <nömrə>');
            return;
        }

        try {
            const rawInput = parts[1];
            const normalized = this.normalizePhone(rawInput);

            if (!normalized) {
                await message.reply('❌ Nömrə düzgün formatda deyil!');
                return;
            }

            const result = this.dataManager.unbanUser(normalized);

            if (result) {
                await message.reply(`🔓 ${this.formatPhoneNumber(normalized)} unban edildi!`);
                this.logger.security('🔓 İstifadəçi unban edildi:', { phoneNumber: normalized }, 'security');
            } else {
                await message.reply(`❌ ${this.formatPhoneNumber(normalized)} ban siyahısında tapılmadı.`);
            }

        } catch (error) {
            this.logger.error('❌ Unban xətası:', error, 'security');
            await message.reply('❌ Unban edilərkən xəta baş verdi.');
        }
    }

    /**
     * Handle /listban command
     * @param {Object} message - WhatsApp message
     */
    async handleListBan(message) {
        const bannedUsers = this.dataManager.getBannedUsers();

        if (bannedUsers.length === 0) {
            await message.reply('ℹ️ Ban siyahısı boşdur.');
            return;
        }

        let banList = `🔨 BAN SİYAHISI (${bannedUsers.length} istifadəçi):\n\n`;

        bannedUsers.forEach((user, index) => {
            const normalized = this.normalizePhone(user) || user;
            banList += `${index + 1}. ${this.formatPhoneNumber(normalized)}\n`;
        });

        await message.reply(banList);
        this.logger.security('📋 Ban siyahısı göstərildi', { count: bannedUsers.length }, 'security');
    }

    /**
     * Handle /admin add command
     * @param {Object} message - WhatsApp message
     */
    async handleAdminAdd(message) {
        const parts = message.body.split(' ');
        if (parts.length < 3) {
            await message.reply('❌ İstifadə: /admin add <nömrə>\nNümunə: /admin add 994506799917');
            return;
        }

        try {
            let phoneNumber = parts[2];

            if (!phoneNumber.includes('@c.us') && !phoneNumber.includes('@g.us')) {
                phoneNumber = phoneNumber + '@c.us';
            }

            const adminIds = this.dataManager.getAdmins();
            if (!adminIds.includes(phoneNumber)) {
                this.dataManager.addAdmin(phoneNumber);

                // Generate temp password for dashboard access
                const normalizedPhone = this.normalizePhone(phoneNumber);
                const tempPassword = await this.generateTempPassword(normalizedPhone);

                const formattedNumber = this.formatPhoneNumber(phoneNumber);

                // Notify the command issuer
                await message.reply(
                    `✅ ${formattedNumber} admin olaraq əlavə edildi!\n\n` +
                    `📱 Dashboard girişi üçün müvəqqəti şifrə göndərildi.`
                );

                // Send temp password to the new admin
                try {
                    await this.client.sendMessage(phoneNumber,
                        `🎉 *ADNSU IT Dashboard Admin*\n\n` +
                        `Siz admin olaraq təyin edildiniz!\n\n` +
                        `📱 *Telefon:* ${formattedNumber}\n` +
                        `🔑 *Müvəqqəti şifrə:* \`${tempPassword}\`\n\n` +
                        `🌐 Dashboard: http://localhost:3000/login.html\n\n` +
                        `⚠️ İlk girişdə şifrənizi dəyişməlisiniz.`
                    );
                } catch (sendErr) {
                    this.logger.warn('Could not send temp password to new admin', sendErr);
                }

                this.logger.security('👮‍♂️ Yeni admin əlavə edildi:', { phoneNumber: phoneNumber }, 'security');
            } else {
                const formattedNumber = this.formatPhoneNumber(phoneNumber);
                await message.reply(`ℹ️ ${formattedNumber} artıq admin idi.`);
            }

        } catch (error) {
            this.logger.error('❌ Admin əlavə etmə xətası:', error, 'security');
            await message.reply('❌ Admin əlavə edilərkən xəta baş verdi.');
        }
    }

    /**
     * Generate temp password for new admin
     * @param {string} phone - Admin phone
     * @returns {Promise<string>} Temp password
     */
    async generateTempPassword(phone) {
        const crypto = require('crypto');
        const tempPass = crypto.randomBytes(4).toString('hex').toUpperCase();

        // Hash password
        let hash;
        try {
            const bcrypt = require('bcrypt');
            hash = await bcrypt.hash(tempPass, 12);
        } catch (e) {
            const salt = crypto.randomBytes(16).toString('hex');
            hash = salt + ':' + crypto.pbkdf2Sync(tempPass, salt, 100000, 64, 'sha512').toString('hex');
        }

        // Store with must_change = 1
        await this.db.run(
            `INSERT OR REPLACE INTO admin_passwords (phone, password_hash, must_change, created_at, updated_at) 
             VALUES (?, ?, 1, datetime('now'), datetime('now'))`,
            [phone, hash]
        );

        return tempPass;
    }

    /**
     * Handle /admin remove command
     * @param {Object} message - WhatsApp message
     */
    async handleAdminRemove(message) {
        const parts = message.body.split(' ');
        if (parts.length < 3) {
            await message.reply('❌ İstifadə: /admin remove <nömrə>');
            return;
        }

        try {
            let phoneNumber = parts[2];

            if (!phoneNumber.includes('@c.us') && !phoneNumber.includes('@g.us')) {
                phoneNumber = phoneNumber + '@c.us';
            }

            const adminIds = this.dataManager.getAdmins();
            const index = adminIds.indexOf(phoneNumber);
            if (index > -1) {
                this.dataManager.removeAdmin(phoneNumber);
                const formattedNumber = this.formatPhoneNumber(phoneNumber);
                await message.reply(`✅ ${formattedNumber} admin siyahısından silindi!`);
                this.logger.security('👮‍♂️ Admin silindi:', { phoneNumber: phoneNumber }, 'security');
            } else {
                const formattedNumber = this.formatPhoneNumber(phoneNumber);
                await message.reply(`❌ ${formattedNumber} admin siyahısında tapılmadı.`);
            }

        } catch (error) {
            this.logger.error('❌ Admin silmə xətası:', error, 'security');
            await message.reply('❌ Admin silinərkən xəta baş verdi.');
        }
    }

    /**
     * Handle /admin list command
     * @param {Object} message - WhatsApp message
     */
    async handleAdminList(message) {
        const adminIds = this.dataManager.getAdmins();
        let adminList = `👮‍♂️ ADMIN SİYAHISI:\n\n`;

        if (adminIds.length > 0) {
            adminList += `📋 KONFİQURASİYA ADMİNLƏRİ:\n`;
            adminIds.forEach((adminId, index) => {
                const formattedNumber = this.formatPhoneNumber(adminId);
                adminList += `${index + 1}. ${formattedNumber}\n`;
            });
        } else {
            adminList += `❌ Konfiqurasiya admini yoxdur.\n`;
        }

        await message.reply(adminList);
        this.logger.security('📋 Admin siyahısı göstərildi', { count: adminIds.length }, 'security');
    }

    /**
     * Handle /register command - Set admin display name
     * @param {Object} message - WhatsApp message
     */
    async handleRegister(message) {
        if (!message) return;

        if (message.from.endsWith('@g.us')) {
            await message.reply('❌ Bu komanda yalnız şəxsi söhbətdə işləyir.');
            return;
        }

        const parts = message.body.trim().split(/\s+/);
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /register <Adınız>');
            return;
        }

        const name = parts.slice(1).join(' ');
        const phone = this.normalizePhone(message.from);

        try {
            await this.db.run(`INSERT OR REPLACE INTO admin_profiles (phone, name) VALUES (?, ?)`, [phone, name]);
            await message.reply(`✅ Adınız "${name}" olaraq qeyd edildi.`);
            this.logger.info(`👤 Admin registered: ${phone} -> ${name}`, null, 'system');
        } catch (error) {
            this.logger.error('❌ Register error:', error, 'system');
            await message.reply('❌ Qeydiyyat zamanı xəta baş verdi.');
        }
    }
}

module.exports = AdminHandler;
