/**
 * ExportHandler - Handles all export operations (Excel, PDF, logs, database)
 */
const { MessageMedia } = require('whatsapp-web.js');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const moment = require('moment');

class ExportHandler {
    /**
     * @param {Object} bot - Reference to the main bot instance
     */
    constructor(bot) {
        this.bot = bot;
        this.db = bot.db;
        this.logger = bot.logger;
        this.client = bot.client;
    }

    /**
     * Format phone number for display
     * @param {string} phone - Phone number to format
     * @returns {string}
     */
    formatPhoneNumber(phone) {
        return this.bot.formatPhoneNumber(phone);
    }

    /**
     * Get Baku timezone time
     * @returns {moment.Moment}
     */
    getBakuTime() {
        return moment().utcOffset(240);
    }

    /**
     * Handle /export command - Export tickets to Excel and PDF
     * @param {Object} message - WhatsApp message object
     */
    async handleExport(message) {
        try {
            const tickets = await this.db.all('SELECT * FROM tickets ORDER BY id ASC');

            // ===============================
            // 📊 1) STATISTIKA HAZIRLANMASI
            // ===============================
            const total = tickets.length;
            const open = tickets.filter(t => t.status === 'open');
            const solved = tickets.filter(t => t.status === 'solved');
            const longTerm = tickets.filter(t => t.status === 'long_term');

            // Ən köhnə açıq bilet
            let oldestOpen = null;
            if (open.length > 0) {
                oldestOpen = open.reduce((a, b) =>
                    moment(a.created_at).isBefore(moment(b.created_at)) ? a : b
                );
            }

            // Orta həll müddəti
            let avgSolve = 'Yoxdur';
            const solvedDurations = solved
                .filter(t => t.solved_at)
                .map(t => moment(t.solved_at).diff(moment(t.created_at), 'minutes'));

            if (solvedDurations.length > 0) {
                const avgMin = Math.round(solvedDurations.reduce((a, b) => a + b, 0) / solvedDurations.length);
                avgSolve = avgMin < 60
                    ? `${avgMin} dəqiqə`
                    : `${Math.floor(avgMin / 60)} saat ${avgMin % 60} dəqiqə`;
            }

            // Admin statistika
            const adminCount = {};
            tickets.forEach(t => {
                const adminIdentifier = t.assigned_admin_name || t.assigned_admin;
                if (adminIdentifier) {
                    adminCount[adminIdentifier] = (adminCount[adminIdentifier] || 0) + 1;
                }
            });

            // Bu gün statistika
            const today = moment().format("YYYY-MM-DD");
            const todayCreated = tickets.filter(t => t.created_at.startsWith(today)).length;
            const todaySolved = tickets.filter(t => t.solved_at && t.solved_at.startsWith(today)).length;

            // ===============================
            // 📘 2) EXCEL FAYLI YARADILMASI
            // ===============================
            const excel = new ExcelJS.Workbook();
            const sheet1 = excel.addWorksheet('Tickets');

            sheet1.columns = [
                { header: 'ID', key: 'id', width: 10 },
                { header: 'Opened By', key: 'opened_by', width: 20 },
                { header: 'Phone', key: 'phone', width: 20 },
                { header: 'Closed By', key: 'closed_by', width: 20 },
                { header: 'Corpus', key: 'corpus', width: 10 },
                { header: 'Room', key: 'room', width: 10 },
                { header: 'Priority', key: 'priority', width: 10 },
                { header: 'Problem', key: 'problem', width: 35 },
                { header: 'Solution', key: 'solution', width: 35 },
                { header: 'Status', key: 'status', width: 12 },
                { header: 'Created', key: 'created', width: 20 },
                { header: 'Solved', key: 'solved', width: 20 },
                { header: 'Solve Duration', key: 'duration', width: 18 }
            ];

            tickets.forEach(t => {
                let duration = '';
                if (t.solved_at) {
                    const min = moment(t.solved_at).diff(moment(t.created_at), 'minutes');
                    duration = min < 60 ? `${min} dəqiqə` : `${Math.floor(min / 60)} saat ${min % 60} dəqiqə`;
                }

                sheet1.addRow({
                    id: t.id,
                    opened_by: t.username,
                    phone: t.phone || this.formatPhoneNumber(t.user_id || t.user),
                    closed_by: t.assigned_admin_name || t.assigned_admin || '',
                    corpus: t.corpus,
                    room: t.room,
                    priority: t.priority || 'normal',
                    problem: t.problem_type,
                    solution: t.solution || '',
                    status: t.status,
                    created: t.created_at,
                    solved: t.solved_at || '',
                    duration: duration
                });
            });

            // --- SHEET 2: STATISTIKA ---
            const sheet2 = excel.addWorksheet('Statistika');
            sheet2.addRow(["STATISTIKA"]).font = { bold: true, size: 16 };
            sheet2.addRow([]);
            sheet2.addRow(["Ümumi Ticket", total]);
            sheet2.addRow(["Açıq Ticket", open.length]);
            sheet2.addRow(["Uzunmüddətli", longTerm.length]);
            sheet2.addRow(["Həll Edilmiş", solved.length]);
            sheet2.addRow(["Orta həll müddəti", avgSolve]);

            if (oldestOpen)
                sheet2.addRow(["Ən köhnə açıq ticket", `#${oldestOpen.id} – ${moment(oldestOpen.created_at).fromNow()} əvvəl`]);

            sheet2.addRow([]);
            sheet2.addRow(["ADMIN STATISTIKASI"]).font = { bold: true, size: 14 };

            for (const [admin, count] of Object.entries(adminCount)) {
                sheet2.addRow([admin, count]);
            }

            sheet2.addRow([]);
            sheet2.addRow(["BU GÜN"]);
            sheet2.addRow(["Bu gün açılan", todayCreated]);
            sheet2.addRow(["Bu gün həll edilən", todaySolved]);

            const excelPath = './export.xlsx';
            await excel.xlsx.writeFile(excelPath);

            // ===============================
            // 📄 3) PDF FAYLI YARADILMASI
            // ===============================
            const pdfPath = './export.pdf';
            await new Promise((resolve, reject) => {
                const pdf = new PDFDocument({ margin: 30 });
                const stream = fs.createWriteStream(pdfPath);

                stream.on('error', (err) => {
                    this.logger.error('❌ PDF stream error:', err, 'commands');
                    reject(err);
                });

                pdf.on('error', (err) => {
                    this.logger.error('❌ PDF document error:', err, 'commands');
                    reject(err);
                });

                pdf.pipe(stream);
                pdf.fontSize(20).text('ADNSU IT Export', { align: 'center' });
                pdf.moveDown();

                pdf.fontSize(14).text("📊 STATİSTİKA");
                pdf.fontSize(11).text(`Ümumi ticket: ${total}`);
                pdf.text(`Açıq ticket: ${open.length}`);
                pdf.text(`Uzunmüddətli: ${longTerm.length}`);
                pdf.text(`Həll edilən: ${solved.length}`);
                pdf.text(`Orta həll müddəti: ${avgSolve}`);

                if (oldestOpen)
                    pdf.text(`Ən köhnə açıq ticket: #${oldestOpen.id} (${moment(oldestOpen.created_at).fromNow()} əvvəl)`);

                pdf.moveDown();
                pdf.fontSize(14).text("👨‍💻 Admin statistikası");
                pdf.fontSize(11);
                for (const [admin, count] of Object.entries(adminCount)) {
                    pdf.text(`${admin}: ${count} ticket`);
                }

                pdf.moveDown();
                pdf.fontSize(14).text("📅 Bu gün");
                pdf.fontSize(11).text(`Bu gün açılan: ${todayCreated}`);
                pdf.text(`Bu gün həll edilən: ${todaySolved}`);

                pdf.moveDown(2);
                pdf.fontSize(16).text("🎫 Ticket List");
                pdf.moveDown();

                tickets.forEach(t => {
                    pdf.fontSize(11).text(
                        `#${t.id} | ${t.username} | ${t.phone || this.formatPhoneNumber(t.user_id || t.user)} | K${t.corpus}-${t.room}\n` +
                        `Problem: ${t.problem_type}\n` +
                        (t.solution ? `Solution: ${t.solution}\n` : '') +
                        `Created: ${t.created_at}\n` +
                        `Solved: ${t.solved_at || '---'}\n`
                    );
                    pdf.moveDown();
                });

                pdf.end();
                stream.on('finish', resolve);
                stream.on('error', reject);
            });

            // ===============================
            // 📤 4) FAYLLARIN GÖNDƏRİLMƏSİ
            // ===============================
            await message.reply("📤 Export hazırdır! Fayllar göndərilir...");
            await this.client.sendMessage(message.from, MessageMedia.fromFilePath(excelPath));
            await this.client.sendMessage(message.from, MessageMedia.fromFilePath(pdfPath));

            this.logger.info('📤 Export göndərildi', { to: message.from }, 'commands');

        } catch (err) {
            this.logger.error('❌ Export xətası:', err, 'commands');
            await message.reply('❌ Export zamanı xəta baş verdi');
        }
    }

    /**
     * Handle /logexport command - Export log files as ZIP
     * @param {Object} message - WhatsApp message object
     */
    async handleLogExport(message) {
        try {
            const logFolder = './logs';
            const outputFile = `./logs_export_${moment().format('YYYY-MM-DD_HH-mm-ss')}.zip`;

            const output = fs.createWriteStream(outputFile);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('error', (err) => {
                this.logger.error('❌ Stream error in log export:', err, 'commands');
                throw err;
            });

            archive.on('error', (err) => {
                this.logger.error('❌ Archive error in log export:', err, 'commands');
                throw err;
            });

            archive.pipe(output);
            archive.directory(logFolder, false);
            await archive.finalize();

            await new Promise((resolve, reject) => {
                output.on('close', resolve);
                output.on('error', reject);
            });

            await message.reply("📦 Log faylları hazırlandı, göndərilir...");
            await this.client.sendMessage(message.from, MessageMedia.fromFilePath(outputFile));

            this.logger.info("📤 Logexport göndərildi", { file: outputFile }, "commands");

            // Clean up file after sending
            setTimeout(() => {
                if (fs.existsSync(outputFile)) {
                    fs.unlinkSync(outputFile);
                }
            }, 5000);

        } catch (err) {
            this.logger.error("❌ Logexport xətası:", err, "commands");
            await message.reply("❌ Logexport zamanı xəta baş verdi!");
        }
    }

    /**
     * Handle /databaseexport command - Export database files as ZIP
     * @param {Object} message - WhatsApp message object
     */
    async handleDatabaseExport(message) {
        try {
            const filesToZip = ['./tickets.db', 'tickets.db-wal', 'tickets.db-shm', 'database.js', './config.json', './admins.js', './bannedusers.json'];
            const missing = filesToZip.filter(f => !fs.existsSync(f));

            if (missing.length > 0) {
                await message.reply(`❌ Aşağıdakı fayllar tapılmadı: ${missing.join(', ')}`);
                return;
            }

            const outputFile = `./database_export_${moment().format('YYYY-MM-DD_HH-mm-ss')}.zip`;
            const output = fs.createWriteStream(outputFile);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('error', (err) => {
                this.logger.error('❌ Stream error in database export:', err, 'commands');
                throw err;
            });

            archive.on('error', (err) => {
                this.logger.error('❌ Archive error in database export:', err, 'commands');
                throw err;
            });

            archive.pipe(output);
            filesToZip.forEach(f => {
                if (fs.existsSync(f)) {
                    archive.file(f, { name: path.basename(f) });
                }
            });

            // Add longphoto directory if exists
            if (fs.existsSync('./longphoto')) {
                archive.directory('./longphoto', 'longphoto');
            }

            await archive.finalize();

            await new Promise((resolve, reject) => {
                output.on('close', resolve);
                output.on('error', reject);
            });

            await message.reply("📦 Database faylları hazırlandı, göndərilir...");
            await this.client.sendMessage(message.from, MessageMedia.fromFilePath(outputFile));

            this.logger.security('📤 Database export göndərildi', { file: outputFile }, 'security');

            // Clean up file after sending
            setTimeout(() => {
                if (fs.existsSync(outputFile)) {
                    fs.unlinkSync(outputFile);
                }
            }, 5000);

        } catch (err) {
            this.logger.error('❌ Database export xətası:', err, 'commands');
            await message.reply('❌ Database export zamanı xəta baş verdi!');
        }
    }
}

module.exports = ExportHandler;
