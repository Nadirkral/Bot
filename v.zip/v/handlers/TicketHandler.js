/**
 * TicketHandler - Handles ticket-related operations
 * Create, solve, assign, list tickets
 */
const moment = require('moment');
const phoneNormalizer = require('../utils/PhoneNormalizer');

class TicketHandler {
    /**
     * @param {Object} bot - Reference to the main bot instance
     */
    constructor(bot) {
        this.bot = bot;
        this.db = bot.db;
        this.logger = bot.logger;
        this.client = bot.client;
        this.configManager = bot.configManager;
        this.rateLimiter = bot.rateLimiter;
        this.userStates = bot.userStates;
        this.problemTypesExtended = bot.problemTypesExtended;
    }

    /**
     * Priority levels for tickets
     */
    static PRIORITIES = {
        'low': '🟢 Aşağı',
        'normal': '🟡 Normal',
        'high': '🟠 Yüksək',
        'urgent': '🔴 Təcili'
    };

    /**
     * Get Baku timezone time
     * @returns {moment.Moment}
     */
    getBakuTime() {
        return moment().utcOffset(240);
    }

    /**
     * Normalize phone number using centralized PhoneNormalizer
     * @param {string} phone - Phone to normalize
     * @returns {string|null}
     */
    normalizePhone(phone) {
        return phoneNormalizer.normalize(phone);
    }

    /**
     * Format phone number for display
     * @param {string} phone - Phone to format
     * @returns {string}
     */
    formatPhoneNumber(phone) {
        return this.bot.formatPhoneNumber(phone);
    }

    /**
     * Calculate open duration for a ticket
     * @param {string} createdAt - Creation timestamp
     * @returns {string}
     */
    calculateOpenDuration(createdAt) {
        const created = moment(createdAt);
        const now = this.getBakuTime();
        const duration = moment.duration(now.diff(created));
        const hours = Math.floor(duration.asHours());
        const minutes = duration.minutes();

        if (hours > 0) {
            return `${hours} saat ${minutes} dəqiqə`;
        } else {
            return `${minutes} dəqiqə`;
        }
    }

    /**
     * Calculate solve duration for a ticket
     * @param {string} createdAt - Creation timestamp
     * @param {string} solvedAt - Solved timestamp
     * @returns {string}
     */
    calculateSolveDuration(createdAt, solvedAt) {
        const created = moment(createdAt);
        const solved = moment(solvedAt);
        const duration = moment.duration(solved.diff(created));
        const hours = Math.floor(duration.asHours());
        const minutes = duration.minutes();

        if (hours > 0) {
            return `${hours} saat ${minutes} dəqiqə`;
        } else {
            return `${minutes} dəqiqə`;
        }
    }

    /**
     * Mark ticket as solved
     * @param {Object} message - WhatsApp message
     * @param {string} adminName - Admin name
     */
    async markSolved(message, adminName) {
        const parts = message.body.split(' ');
        if (parts.length < 3) {
            await message.reply('❌ İstifadə: /solved <ticket_id> <həll üsulu>');
            return;
        }

        const ticketId = parseInt(parts[1]);
        const solution = parts.slice(2).join(' ');

        try {
            const ticket = await this.db.get('SELECT * FROM tickets WHERE id = ?', [ticketId]);
            if (!ticket) {
                await message.reply('❌ Ticket tapılmadı!');
                return;
            }

            if (ticket.status === 'solved') {
                await message.reply('❌ Bu ticket artıq həll edilib!');
                return;
            }

            const solvedAt = this.getBakuTime().format('YYYY-MM-DD HH:mm:ss');
            const solveDuration = this.calculateSolveDuration(ticket.created_at, solvedAt);
            const adminPhone = this.normalizePhone(message.from);

            // Get admin name from profile if exists
            const adminProfile = await this.db.get(`SELECT name FROM admin_profiles WHERE phone = ?`, [adminPhone]);
            const actualAdminName = adminProfile ? adminProfile.name : adminName;

            const sql = `
                UPDATE tickets 
                SET status = ?, assigned_admin = ?, assigned_admin_name = ?, solution = ?, solved_at = ?, solved_by_phone = ?
                WHERE id = ?
            `;
            await this.db.run(sql, ['solved', adminPhone, actualAdminName, solution, solvedAt, adminPhone, ticketId]);

            // Log history
            await this.db.logHistory(ticketId, 'solved', ticket.status, 'solved', actualAdminName);

            const response = `✅ TICKET HƏLL EDİLDİ #${ticketId}\n\n` +
                `👤 ${ticket.username}\n` +
                `🏢 K${ticket.corpus}-${ticket.room}\n` +
                `🔧 ${ticket.problem_type}\n` +
                `🛠️ Həll: ${solution}\n` +
                `👨‍🔧 Təcrübəçi: ${actualAdminName}\n` +
                `⏱️ Həll müddəti: ${solveDuration}\n` +
                `🕐 ${solvedAt}`;

            await message.reply(response);

            this.logger.ticket('✅ Ticket həll edildi:', {
                ticketId: ticketId,
                admin: actualAdminName,
                duration: solveDuration,
                solution: solution
            }, 'tickets');

        } catch (error) {
            this.logger.error('❌ Solved xətası:', error, 'tickets');
            await message.reply('❌ Ticket yenilənərkən xəta baş verdi!');
        }
    }

    /**
     * Mark ticket as long-term
     * @param {Object} message - WhatsApp message
     * @param {string} adminName - Admin name
     */
    async handleLongTerm(message, adminName) {
        const parts = message.body.split(' ');
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /long <ticket_id>');
            return;
        }

        const ticketId = parseInt(parts[1]);

        try {
            const ticket = await this.db.get('SELECT * FROM tickets WHERE id = ?', [ticketId]);
            if (!ticket) {
                await message.reply('❌ Ticket tapılmadı!');
                return;
            }

            if (ticket.status !== 'open') {
                await message.reply(`❌ Bu ticket artıq ${ticket.status} statusundadır!`);
                return;
            }

            const adminPhone = this.normalizePhone(message.from);
            const adminProfile = await this.db.get(`SELECT name FROM admin_profiles WHERE phone = ?`, [adminPhone]);
            const actualAdminName = adminProfile ? adminProfile.name : adminName;

            const longTermAt = this.getBakuTime().format('YYYY-MM-DD HH:mm:ss');
            const sql = `
                UPDATE tickets 
                SET status = ?, assigned_admin = ?, assigned_admin_name = ?, solved_at = ?
                WHERE id = ?
            `;
            await this.db.run(sql, ['long_term', adminPhone, actualAdminName, longTermAt, ticketId]);

            // Log history
            await this.db.logHistory(ticketId, 'status_changed', 'open', 'long_term', actualAdminName);

            const response = `⏳ TICKET UZUNMÜDDƏTLİ #${ticketId}\n\n` +
                `👤 ${ticket.username}\n` +
                `🏢 K${ticket.corpus}-${ticket.room}\n` +
                `🔧 ${ticket.problem_type}\n` +
                `👨‍🔧 Admin: ${actualAdminName}\n` +
                `🕐 ${longTermAt}\n\n` +
                `✅ /solved ${ticketId} <həll üsulu>\n` +
                `📸 /longphoto ${ticketId}`;

            await message.reply(response);

            this.logger.ticket('✅ Ticket uzunmüddətli edildi:', { ticketId: ticketId, admin: actualAdminName }, 'tickets');

        } catch (error) {
            this.logger.error('❌ Long term xətası:', error, 'tickets');
            await message.reply('❌ Ticket yenilənərkən xəta baş verdi!');
        }
    }

    /**
     * Handle /unsolved command - reopen a solved ticket
     * @param {Object} message - WhatsApp message
     */
    async handleUnsolved(message) {
        const parts = message.body.split(' ');
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /unsolved <ticket_id>');
            return;
        }

        const ticketId = parseInt(parts[1]);

        try {
            const ticket = await this.db.get('SELECT id, status FROM tickets WHERE id = ?', [ticketId]);

            if (!ticket) {
                await message.reply('❌ Ticket tapılmadı!');
                return;
            }

            if (ticket.status !== 'solved') {
                await message.reply('ℹ️ Bu ticket solved deyil.');
                return;
            }

            const adminPhone = this.normalizePhone(message.from);
            const adminProfile = await this.db.get(`SELECT name FROM admin_profiles WHERE phone = ?`, [adminPhone]);
            const adminName = adminProfile ? adminProfile.name : message._data.notifyName || 'Admin';

            const sql = `
                UPDATE tickets
                SET status = 'open', solved_at = NULL, assigned_admin = NULL, solution = NULL
                WHERE id = ?
            `;
            await this.db.run(sql, [ticketId]);

            // Log history
            await this.db.logHistory(ticketId, 'reopened', 'solved', 'open', adminName);

            await message.reply(`♻️ Ticket #${ticketId} yenidən açıldı.`);

        } catch (error) {
            this.logger.error('❌ Unsolved xətası:', error, 'tickets');
            await message.reply('❌ Ticket yenidən açılarkən xəta baş verdi.');
        }
    }

    /**
     * Handle /assign command - assign ticket to self
     * @param {Object} message - WhatsApp message
     */
    async handleAssign(message) {
        if (!message) return;

        if (message.from.endsWith('@g.us')) {
            return;
        }

        const parts = message.body.split(' ');
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /assign <ticket_id>');
            return;
        }

        const ticketId = parts[1];
        const adminPhone = this.normalizePhone(message.from);

        try {
            const adminProfile = await this.db.get(`SELECT name FROM admin_profiles WHERE phone = ?`, [adminPhone]);
            const adminName = adminProfile ? adminProfile.name : (message._data.notifyName || adminPhone);

            // Check if admin already has an active ticket
            const activeTicket = await this.db.get(`
                SELECT id FROM tickets 
                WHERE assigned_admin = ? AND status NOT IN ('solved', 'long_term')
            `, [adminPhone]);

            if (activeTicket) {
                await message.reply(`❌ Siz artıq Ticket #${activeTicket.id} ilə məşğulsunuz. Yeni ticket götürmək üçün əvvəlcə onu həll etməli (/solved) və ya imtina etməlisiniz (/noassign).`);
                return;
            }

            const ticket = await this.db.get(`SELECT * FROM tickets WHERE id = ?`, [ticketId]);

            if (!ticket) {
                await message.reply(`❌ Ticket #${ticketId} tapılmadı.`);
                return;
            }

            if (ticket.status === 'solved') {
                await message.reply(`❌ Ticket #${ticketId} artıq həll olunub.`);
                return;
            }

            if (ticket.status === 'long_term') {
                await message.reply(`❌ Ticket #${ticketId} uzunmüddətli ticketdir. Assign olunmur.`);
                return;
            }

            if (ticket.assigned_admin) {
                if (ticket.assigned_admin === adminPhone) {
                    await message.reply(`ℹ️ Bu ticket artıq sizdədir.`);
                } else {
                    const assignedProfile = await this.db.get(`SELECT name FROM admin_profiles WHERE phone = ?`, [ticket.assigned_admin]);
                    const assignedName = assignedProfile ? assignedProfile.name : ticket.assigned_admin;
                    await message.reply(`❌ Bu ticket ilə artıq ${assignedName} məşğul olur.`);
                }
                return;
            }

            // Assign
            await this.db.run(
                `UPDATE tickets SET assigned_admin = ?, assigned_admin_name = ? WHERE id = ?`,
                [adminPhone, adminName, ticketId]
            );

            // Log history
            await this.db.logHistory(ticketId, 'assigned', null, adminName, adminName);

            await message.reply(`✅ Ticket #${ticketId} artıq sizin səlahiyyətinizdədir!`);

            // Notify Group
            const groupId = this.configManager.get('traineeGroupId');
            if (groupId) {
                await this.client.sendMessage(groupId, `👷 Ticket #${ticketId} ilə ${adminName} məşğul olur.`);
            }

            this.logger.info(`👤 Ticket assigned: #${ticketId} to ${adminName} (${adminPhone})`, null, 'tickets');

        } catch (error) {
            this.logger.error('❌ Assign error:', error, 'system');
            await message.reply('❌ Assign zamanı xəta baş verdi.');
        }
    }

    /**
     * Handle /noassign command - unassign ticket from self
     * @param {Object} message - WhatsApp message
     */
    async handleNoAssign(message) {
        if (!message) return;

        if (message.from.endsWith('@g.us')) {
            return;
        }

        const parts = message.body.split(' ');
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /noassign <ticket_id>');
            return;
        }

        const ticketId = parts[1];
        const adminPhone = this.normalizePhone(message.from);

        try {
            const adminProfile = await this.db.get(`SELECT name FROM admin_profiles WHERE phone = ?`, [adminPhone]);
            const adminName = adminProfile ? adminProfile.name : (message._data.notifyName || adminPhone);

            const ticket = await this.db.get(`SELECT * FROM tickets WHERE id = ?`, [ticketId]);

            if (!ticket) {
                await message.reply(`❌ Ticket #${ticketId} tapılmadı.`);
                return;
            }

            if (ticket.assigned_admin !== adminPhone) {
                await message.reply(`❌ Bu ticket sizə aid deyil.`);
                return;
            }

            if (ticket.status === 'solved') {
                await message.reply(`ℹ️ Ticket artıq həll olunub, noassign etməyə ehtiyac yoxdur.`);
                return;
            }

            // Unassign
            await this.db.run(
                `UPDATE tickets SET assigned_admin = NULL, assigned_admin_name = NULL WHERE id = ?`,
                [ticketId]
            );

            // Log history
            await this.db.logHistory(ticketId, 'unassigned', adminName, null, adminName);

            await message.reply(`✅ Ticket #${ticketId} artıq sizdə deyil.`);

            // Notify Group
            const groupId = this.configManager.get('traineeGroupId');
            if (groupId) {
                await this.client.sendMessage(groupId, `🔄 Ticket #${ticketId} ilə hal-hazırda heçkim məşqul olmur.(${adminName} imtina etdi).`);
            }

            this.logger.info(`👤 Ticket unassigned: #${ticketId} by ${adminName} (${adminPhone})`, null, 'tickets');

        } catch (error) {
            this.logger.error('❌ NoAssign error:', error, 'system');
            await message.reply('❌ NoAssign zamanı xəta baş verdi.');
        }
    }

    /**
     * Handle /priority command - set ticket priority
     * @param {Object} message - WhatsApp message
     */
    async handlePriority(message) {
        const parts = message.body.split(' ');
        if (parts.length < 3) {
            const priorities = Object.entries(TicketHandler.PRIORITIES)
                .map(([key, val]) => `  ${key} - ${val}`)
                .join('\n');
            await message.reply(`❌ İstifadə: /priority <ticket_id> <səviyyə>\n\nSəviyyələr:\n${priorities}`);
            return;
        }

        const ticketId = parseInt(parts[1]);
        const priority = parts[2].toLowerCase();

        if (!TicketHandler.PRIORITIES[priority]) {
            await message.reply(`❌ Yanlış prioritet. İstifadə edin: low, normal, high, urgent`);
            return;
        }

        try {
            const ticket = await this.db.get('SELECT * FROM tickets WHERE id = ?', [ticketId]);
            if (!ticket) {
                await message.reply('❌ Ticket tapılmadı!');
                return;
            }

            const adminPhone = this.normalizePhone(message.from);
            const adminProfile = await this.db.get(`SELECT name FROM admin_profiles WHERE phone = ?`, [adminPhone]);
            const adminName = adminProfile ? adminProfile.name : message._data.notifyName || 'Admin';

            await this.db.run('UPDATE tickets SET priority = ? WHERE id = ?', [priority, ticketId]);

            // Log history
            await this.db.logHistory(ticketId, 'priority_changed', ticket.priority || 'normal', priority, adminName);

            await message.reply(`✅ Ticket #${ticketId} prioriteti ${TicketHandler.PRIORITIES[priority]} olaraq dəyişdirildi.`);

        } catch (error) {
            this.logger.error('❌ Priority xətası:', error, 'tickets');
            await message.reply('❌ Prioritet dəyişdirilə bilmədi.');
        }
    }

    /**
     * Handle /history command - show ticket history
     * @param {Object} message - WhatsApp message
     */
    async handleHistory(message) {
        const parts = message.body.split(' ');
        if (parts.length < 2) {
            await message.reply('❌ İstifadə: /history <ticket_id>');
            return;
        }

        const ticketId = parseInt(parts[1]);

        try {
            const ticket = await this.db.get('SELECT * FROM tickets WHERE id = ?', [ticketId]);
            if (!ticket) {
                await message.reply('❌ Ticket tapılmadı!');
                return;
            }

            const history = await this.db.getHistory(ticketId);

            if (history.length === 0) {
                await message.reply(`ℹ️ Ticket #${ticketId} üçün tarixçə tapılmadı.`);
                return;
            }

            let historyText = `📜 TICKET #${ticketId} TARİXÇƏSİ\n\n`;

            history.forEach((entry, index) => {
                const time = moment(entry.changed_at).format('DD.MM.YYYY HH:mm');
                historyText += `${index + 1}. ${entry.action}\n`;
                historyText += `   📅 ${time}\n`;
                historyText += `   👤 ${entry.changed_by || 'System'}\n`;
                if (entry.old_value || entry.new_value) {
                    historyText += `   ${entry.old_value || '-'} → ${entry.new_value || '-'}\n`;
                }
                historyText += '\n';
            });

            await message.reply(historyText);

        } catch (error) {
            this.logger.error('❌ History xətası:', error, 'tickets');
            await message.reply('❌ Tarixçə gətirilərkən xəta baş verdi.');
        }
    }
}

module.exports = TicketHandler;
