/**
 * PhoneNormalizer - Centralized phone number normalization utility
 * Single source of truth for all phone/WhatsApp ID normalization
 * 
 * Handles all WhatsApp ID formats:
 * - @c.us (contacts)
 * - @s.whatsapp.net (some API versions)
 * - @g.us (groups)
 * - @lid (leads)
 * - Evolution API lead/contact differences
 */

class PhoneNormalizer {
    /**
     * Normalize any WhatsApp ID to pure phone number format: 994XXXXXXXXX
     * Handles: @c.us, @s.whatsapp.net, @g.us, @lid, leads, contacts
     * 
     * @param {string|number} input - Raw phone/WhatsApp ID
     * @returns {string|null} Normalized phone (994XXXXXXXXX) or null if invalid
     */
    normalize(input) {
        if (!input) return null;

        let phone = input.toString();

        // Strip WhatsApp suffixes (@c.us, @s.whatsapp.net, @g.us, @lid:xxxxx)
        phone = phone
            .replace(/@c\.us$/i, '')
            .replace(/@s\.whatsapp\.net$/i, '')
            .replace(/@g\.us$/i, '')
            .replace(/@lid:[^@]*$/i, '')
            .replace(/@lid$/i, '');

        // Remove all non-digit characters
        phone = phone.replace(/\D/g, '');

        // Handle various formats
        if (phone.startsWith('00994')) {
            phone = phone.slice(2); // 00994 → 994
        }

        if (phone.startsWith('994') && phone.length === 12) {
            return phone;
        }

        if (phone.startsWith('0') && phone.length === 10) {
            return '994' + phone.slice(1);
        }

        if (phone.length === 9) {
            return '994' + phone;
        }

        // If already looks like a valid number, try to normalize
        if (phone.length >= 9 && phone.length <= 15) {
            // If it's 12 digits and might be international, return as-is
            if (phone.length === 12) {
                return phone;
            }
            // Otherwise, can't reliably normalize
            return null;
        }

        return null;
    }

    /**
     * Extract the actual sender ID from a WhatsApp message
     * Handles both group and private message contexts correctly
     * 
     * @param {Object} message - WhatsApp message object
     * @param {boolean|null} isGroup - Force group context, or auto-detect if null
     * @returns {string} Raw sender ID (before normalization)
     */
    extractSenderId(message, isGroup = null) {
        if (!message) return null;

        // Auto-detect group context if not specified
        if (isGroup === null) {
            isGroup = message.from?.endsWith('@g.us') || false;
        }

        if (isGroup) {
            // In groups: use author or fallbacks
            // Priority: message.author → message.id.participant → message._data.author → message.from
            return message.author
                || (message.id && message.id.participant)
                || (message._data && message._data.author)
                || message.from;
        }

        // Private messages: use from directly
        return message.from;
    }

    /**
     * Get normalized sender phone from message
     * Single function for all sender identification needs
     * 
     * @param {Object} message - WhatsApp message object
     * @returns {string|null} Normalized phone number (994XXXXXXXXX) or null
     */
    getSenderPhone(message) {
        const rawId = this.extractSenderId(message);
        return this.normalize(rawId);
    }

    /**
     * Check if two phone numbers/IDs represent the same user
     * 
     * @param {string} id1 - First phone/WhatsApp ID
     * @param {string} id2 - Second phone/WhatsApp ID
     * @returns {boolean} True if same user
     */
    isSameUser(id1, id2) {
        const normalized1 = this.normalize(id1);
        const normalized2 = this.normalize(id2);

        if (!normalized1 || !normalized2) return false;
        return normalized1 === normalized2;
    }

    /**
     * Format phone number for display
     * 
     * @param {string} phone - Phone number or WhatsApp ID
     * @returns {string} Formatted display string
     */
    formatForDisplay(phone) {
        const normalized = this.normalize(phone);
        if (!normalized) return phone || 'Unknown';

        // Format as +994 XX XXX XX XX
        if (normalized.length === 12 && normalized.startsWith('994')) {
            return `+${normalized.slice(0, 3)} ${normalized.slice(3, 5)} ${normalized.slice(5, 8)} ${normalized.slice(8, 10)} ${normalized.slice(10)}`;
        }

        return `+${normalized}`;
    }
}

// Export singleton instance for consistent usage across the app
module.exports = new PhoneNormalizer();
