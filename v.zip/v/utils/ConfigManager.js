const fs = require('fs');
const path = require('path');

class ConfigManager {
    constructor(configPath = './config.json') {
        this.configPath = configPath;
        this.config = this.loadConfig();
    }

    loadConfig() {
        try {
            if (fs.existsSync(this.configPath)) {
                const data = fs.readFileSync(this.configPath, 'utf8');
                return JSON.parse(data);
            } else {
                // Default config - REQUIRES user to set credentials before use
                const defaultConfig = {
                    adminCredentials: {
                        username: 'CHANGE_ME',
                        password: 'CHANGE_ME_IMMEDIATELY'
                    },
                    traineeGroupId: '', // WhatsApp qrup ID-si - run /groupid in group to set
                    reminderInterval: 30, // dəqiqə
                    photoSettings: {
                        maxFileSize: 5, // MB
                        maxPhotosPerTicket: 10
                    },
                    rateLimits: {
                        perMinute: 1,
                        perHour: 5,
                        perDay: 20
                    },
                    dashboardPort: 3000
                };
                console.log('⚠️ Default config created. Please update config.json with secure credentials!');
                this.saveConfig(defaultConfig);
                return defaultConfig;
            }
        } catch (error) {
            console.error('❌ Config yüklənərkən xəta:', error);
            throw error;
        }
    }

    get(key = null) {
        if (key) {
            return this.config[key];
        }
        return this.config;
    }

    set(key, value) {
        this.config[key] = value;
        this.saveConfig(this.config);
    }

    saveConfig(config) {
        try {
            const dir = path.dirname(this.configPath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            fs.writeFileSync(this.configPath, JSON.stringify(config, null, 2), 'utf8');
        } catch (error) {
            console.error('❌ Config saxlanılarkən xəta:', error);
            throw error;
        }
    }
}

module.exports = ConfigManager;
