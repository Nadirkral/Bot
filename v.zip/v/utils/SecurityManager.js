/**
 * SecurityManager - Enterprise-grade security for dashboard
 * OWASP Top 10 compliant, ISO 27001/27002 aligned
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

class SecurityManager {
    constructor(db, logger = null) {
        this.db = db;
        this.logger = logger;
        this.JWT_SECRET = this.getOrCreateSecret();
        this.TOKEN_EXPIRY = '8h';
        this.BCRYPT_ROUNDS = 12;
        this.MAX_LOGIN_ATTEMPTS = 5;
        this.LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes
        this.failedAttempts = new Map();
        this.csrfTokens = new Map();

        // Security headers for OWASP compliance
        this.securityHeaders = {
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
            'X-XSS-Protection': '1; mode=block',
            'Referrer-Policy': 'strict-origin-when-cross-origin',
            'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'",
            'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
            'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
            'Pragma': 'no-cache'
        };
    }

    /**
     * Get or create JWT secret key
     */
    getOrCreateSecret() {
        const secretPath = path.join(__dirname, '..', '.jwt_secret');
        try {
            if (fs.existsSync(secretPath)) {
                return fs.readFileSync(secretPath, 'utf8').trim();
            }
        } catch (e) { }

        // Generate new 256-bit secret
        const secret = crypto.randomBytes(32).toString('hex');
        try {
            fs.writeFileSync(secretPath, secret, { mode: 0o600 });
        } catch (e) {
            console.warn('Could not persist JWT secret');
        }
        return secret;
    }

    /**
     * Hash password using bcrypt
     * @param {string} password - Plain text password
     * @returns {Promise<string>} Hashed password
     */
    async hashPassword(password) {
        try {
            const bcrypt = require('bcrypt');
            return await bcrypt.hash(password, this.BCRYPT_ROUNDS);
        } catch (e) {
            // Fallback to crypto if bcrypt not available
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
            return `${salt}:${hash}`;
        }
    }

    /**
     * Verify password against hash
     * @param {string} password - Plain text password
     * @param {string} hash - Stored hash
     * @returns {Promise<boolean>}
     */
    async verifyPassword(password, hash) {
        try {
            const bcrypt = require('bcrypt');
            return await bcrypt.compare(password, hash);
        } catch (e) {
            // Fallback verification
            if (hash.includes(':')) {
                const [salt, storedHash] = hash.split(':');
                const testHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
                return storedHash === testHash;
            }
            return false;
        }
    }

    /**
     * Generate JWT token
     * @param {Object} payload - Token payload
     * @returns {string} JWT token
     */
    generateToken(payload) {
        try {
            const jwt = require('jsonwebtoken');
            return jwt.sign(payload, this.JWT_SECRET, { expiresIn: this.TOKEN_EXPIRY });
        } catch (e) {
            // Fallback simple token
            const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
            const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + 8 * 60 * 60 * 1000 })).toString('base64url');
            const signature = crypto.createHmac('sha256', this.JWT_SECRET).update(`${header}.${body}`).digest('base64url');
            return `${header}.${body}.${signature}`;
        }
    }

    /**
     * Verify JWT token
     * @param {string} token - JWT token
     * @returns {Object|null} Decoded payload or null
     */
    verifyToken(token) {
        try {
            const jwt = require('jsonwebtoken');
            return jwt.verify(token, this.JWT_SECRET);
        } catch (e) {
            // Fallback verification
            try {
                const parts = token.split('.');
                if (parts.length !== 3) return null;

                const [header, body, signature] = parts;
                const expectedSig = crypto.createHmac('sha256', this.JWT_SECRET).update(`${header}.${body}`).digest('base64url');

                if (signature !== expectedSig) return null;

                const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
                if (payload.exp && payload.exp < Date.now()) return null;

                return payload;
            } catch (err) {
                return null;
            }
        }
    }

    /**
     * Generate CSRF token
     * @param {string} sessionId - Session identifier
     * @returns {string} CSRF token
     */
    generateCSRFToken(sessionId) {
        const token = crypto.randomBytes(32).toString('hex');
        this.csrfTokens.set(sessionId, { token, expires: Date.now() + 3600000 });
        return token;
    }

    /**
     * Verify CSRF token
     * @param {string} sessionId - Session identifier
     * @param {string} token - CSRF token to verify
     * @returns {boolean}
     */
    verifyCSRFToken(sessionId, token) {
        const stored = this.csrfTokens.get(sessionId);
        if (!stored || stored.expires < Date.now()) {
            this.csrfTokens.delete(sessionId);
            return false;
        }
        return stored.token === token;
    }

    /**
     * Check rate limiting for login attempts
     * @param {string} identifier - IP or user identifier
     * @returns {Object} { allowed: boolean, remainingAttempts: number, lockoutRemaining: number }
     */
    checkRateLimit(identifier) {
        const now = Date.now();
        const record = this.failedAttempts.get(identifier);

        if (!record) {
            return { allowed: true, remainingAttempts: this.MAX_LOGIN_ATTEMPTS, lockoutRemaining: 0 };
        }

        // Check if lockout has expired
        if (record.lockedUntil && record.lockedUntil > now) {
            return {
                allowed: false,
                remainingAttempts: 0,
                lockoutRemaining: Math.ceil((record.lockedUntil - now) / 1000)
            };
        }

        // Reset if lockout expired
        if (record.lockedUntil && record.lockedUntil <= now) {
            this.failedAttempts.delete(identifier);
            return { allowed: true, remainingAttempts: this.MAX_LOGIN_ATTEMPTS, lockoutRemaining: 0 };
        }

        const remaining = this.MAX_LOGIN_ATTEMPTS - record.attempts;
        return { allowed: remaining > 0, remainingAttempts: Math.max(0, remaining), lockoutRemaining: 0 };
    }

    /**
     * Record failed login attempt
     * @param {string} identifier - IP or user identifier
     */
    recordFailedAttempt(identifier) {
        const record = this.failedAttempts.get(identifier) || { attempts: 0 };
        record.attempts++;
        record.lastAttempt = Date.now();

        if (record.attempts >= this.MAX_LOGIN_ATTEMPTS) {
            record.lockedUntil = Date.now() + this.LOCKOUT_DURATION;
        }

        this.failedAttempts.set(identifier, record);
        this.logSecurityEvent('FAILED_LOGIN', { identifier, attempts: record.attempts });
    }

    /**
     * Clear failed attempts on successful login
     * @param {string} identifier - IP or user identifier
     */
    clearFailedAttempts(identifier) {
        this.failedAttempts.delete(identifier);
    }

    /**
     * Sanitize input to prevent XSS and injection
     * @param {string} input - Raw input
     * @returns {string} Sanitized input
     */
    sanitizeInput(input) {
        if (typeof input !== 'string') return '';
        return input
            .replace(/[<>]/g, '') // Remove HTML tags
            .replace(/javascript:/gi, '') // Remove javascript:
            .replace(/on\w+=/gi, '') // Remove event handlers
            .replace(/['";]/g, '') // Remove quotes
            .trim()
            .substring(0, 1000); // Limit length
    }

    /**
     * Validate phone number format
     * @param {string} phone - Phone number
     * @returns {boolean}
     */
    validatePhone(phone) {
        if (!phone || typeof phone !== 'string') return false;
        const cleaned = phone.replace(/\D/g, '');
        return cleaned.length >= 9 && cleaned.length <= 15;
    }

    /**
     * Validate password strength
     * @param {string} password - Password to validate
     * @returns {Object} { valid: boolean, message: string }
     */
    validatePassword(password) {
        if (!password || password.length < 6) {
            return { valid: false, message: 'Password must be at least 6 characters' };
        }
        return { valid: true, message: 'OK' };
    }

    /**
     * Apply security headers to response
     * @param {Object} res - Express response object
     */
    applySecurityHeaders(res) {
        Object.entries(this.securityHeaders).forEach(([header, value]) => {
            res.setHeader(header, value);
        });
    }

    /**
     * Log security event
     * @param {string} eventType - Type of event
     * @param {Object} details - Event details
     */
    async logSecurityEvent(eventType, details = {}) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            type: eventType,
            ...details
        };

        if (this.logger) {
            this.logger.warn(`🔒 Security Event: ${eventType}`, details, 'security');
        }

        // Store in database if available
        if (this.db) {
            try {
                await this.db.run(
                    'INSERT INTO security_logs (event_type, details, created_at) VALUES (?, ?, ?)',
                    [eventType, JSON.stringify(details), new Date().toISOString()]
                );
            } catch (e) {
                // Table might not exist yet
            }
        }

        console.log(`🔒 [SECURITY] ${eventType}:`, JSON.stringify(details));
    }

    /**
     * Generate session ID
     * @returns {string}
     */
    generateSessionId() {
        return crypto.randomBytes(32).toString('hex');
    }

    /**
     * Get client IP safely
     * @param {Object} req - Express request object
     * @returns {string}
     */
    getClientIP(req) {
        return req.headers['x-forwarded-for']?.split(',')[0]?.trim()
            || req.connection?.remoteAddress
            || req.ip
            || 'unknown';
    }

    /**
     * Cleanup expired tokens and sessions
     */
    cleanup() {
        const now = Date.now();

        // Cleanup CSRF tokens
        for (const [key, value] of this.csrfTokens.entries()) {
            if (value.expires < now) {
                this.csrfTokens.delete(key);
            }
        }

        // Cleanup old failed attempts
        for (const [key, value] of this.failedAttempts.entries()) {
            if (value.lockedUntil && value.lockedUntil < now - 3600000) {
                this.failedAttempts.delete(key);
            }
        }
    }
}

module.exports = SecurityManager;
