const fs = require('fs');
const path = require('path');
const phoneNormalizer = require('./PhoneNormalizer');

class DataManager {
    constructor() {
        // ✅ Use absolute paths to prevent issues when PM2 changes working directory
        this.adminsFile = path.resolve(__dirname, '../admins.js');
        this.bannedUsersFile = path.resolve(__dirname, '../bannedusers.json');

        this.admins = [];
        this.bannedUsers = [];

        console.log('📂 DataManager fayl yolları:', {
            adminsFile: this.adminsFile,
            bannedUsersFile: this.bannedUsersFile
        });

        this.loadData();
    }

    loadData() {
        // Load admins from .js file
        try {
            console.log('📂 Adminlər yüklənir:', this.adminsFile);
            if (fs.existsSync(this.adminsFile)) {
                // Get absolute path for cache clearing
                const absolutePath = path.resolve(this.adminsFile);

                // Delete from cache to reload fresh data
                delete require.cache[absolutePath];

                const adminData = require(absolutePath);
                this.admins = adminData.admins || [];
                console.log('✅ Adminlər yükləndi:', {
                    count: this.admins.length,
                    admins: this.admins
                });
            } else {
                console.log('⚠️ admins.js faylı tapılmadı, yeni fayl yaradılır');
                this.saveAdmins();
            }
        } catch (error) {
            console.error('❌ Admins yüklənərkən xəta:', error);
            console.error('Stack trace:', error.stack);
            this.admins = [];
            this.saveAdmins();
        }

        // Load banned users
        try {
            if (fs.existsSync(this.bannedUsersFile)) {
                const data = fs.readFileSync(this.bannedUsersFile, 'utf8');
                const parsed = JSON.parse(data);
                this.bannedUsers = parsed.bannedUsers || [];
            } else {
                this.saveBannedUsers();
            }
        } catch (error) {
            console.error('❌ Banlı istifadəçilər yüklənərkən xəta:', error);
            this.bannedUsers = [];
            this.saveBannedUsers();
        }
    }

    saveAdmins() {
        try {
            console.log('💾 Adminlər saxlanılır:', {
                count: this.admins.length,
                admins: this.admins,
                file: this.adminsFile
            });

            const jsContent = `// ADMIN SİYAHISI
// Bu faylı dəyişdirməyin - DataManager avtomatik idarə edir

module.exports = {
    admins: ${JSON.stringify(this.admins, null, 8)},
    lastUpdated: "${new Date().toISOString()}"
};
`;

            // ✅ Atomic write: write to temp file first, then rename
            const tempFile = this.adminsFile + '.tmp';
            fs.writeFileSync(tempFile, jsContent, 'utf8');

            // Rename temp file to actual file (atomic operation)
            if (fs.existsSync(this.adminsFile)) {
                fs.unlinkSync(this.adminsFile);
            }
            fs.renameSync(tempFile, this.adminsFile);

            // Verify file was written
            if (fs.existsSync(this.adminsFile)) {
                const fileStats = fs.statSync(this.adminsFile);
                console.log('✅ Adminlər uğurla saxlanıldı:', {
                    savedCount: this.admins.length,
                    fileSize: fileStats.size + ' bytes'
                });
            } else {
                console.error('❌ XƏTA: Fayl yazıldıqdan sonra tapılmadı!');
            }
        } catch (error) {
            console.error('❌ Admins saxlanılarkən xəta:', error);
            console.error('Stack trace:', error.stack);
        }
    }

    saveBannedUsers() {
        try {
            const data = {
                bannedUsers: this.bannedUsers,
                lastUpdated: new Date().toISOString()
            };

            // ✅ Atomic write: write to temp file first, then rename
            const tempFile = this.bannedUsersFile + '.tmp';
            fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf8');

            // Rename temp file to actual file (atomic operation)
            if (fs.existsSync(this.bannedUsersFile)) {
                fs.unlinkSync(this.bannedUsersFile);
            }
            fs.renameSync(tempFile, this.bannedUsersFile);
        } catch (error) {
            console.error('❌ Banlı istifadəçilər saxlanılarkən xəta:', error);
        }
    }

    // Phone normalization - delegate to centralized PhoneNormalizer
    _normalize(input) {
        return phoneNormalizer.normalize(input);
    }

    // Public alias for phone normalization
    normalizePhone(input) {
        return this._normalize(input);
    }

    // Admin methods
    addAdmin(phoneNumber) {
        const normalized = this._normalize(phoneNumber);
        if (!normalized) {
            console.log('❌ Admin əlavə edilə bilmədi: Yanlış nömrə formatı', phoneNumber);
            return false;
        }

        console.log('➕ Admin əlavə edilir:', normalized);

        if (!this.admins.includes(normalized)) {
            this.admins.push(normalized);
            this.saveAdmins();
            return true;
        }
        return false;
    }

    removeAdmin(phoneNumber) {
        const normalized = this._normalize(phoneNumber);
        if (!normalized) return false;

        console.log('➖ Admin silinir:', normalized);

        const index = this.admins.indexOf(normalized);
        if (index > -1) {
            this.admins.splice(index, 1);
            this.saveAdmins();
            return true;
        }
        return false;
    }

    getAdmins() {
        return [...this.admins];
    }

    isAdmin(phoneNumber) {
        const normalized = this._normalize(phoneNumber);
        if (!normalized) return false;
        return this.admins.includes(normalized);
    }

    // Banned users methods
    banUser(phoneNumber) {
        const normalized = this._normalize(phoneNumber);
        if (!normalized) {
            console.log('❌ Ban edilə bilmədi: Yanlış nömrə formatı', phoneNumber);
            return false;
        }

        if (!this.bannedUsers.includes(normalized)) {
            this.bannedUsers.push(normalized);
            this.saveBannedUsers();
            return true;
        }
        return false;
    }

    unbanUser(phoneNumber) {
        const normalized = this._normalize(phoneNumber);
        if (!normalized) return false;

        const index = this.bannedUsers.indexOf(normalized);
        if (index > -1) {
            this.bannedUsers.splice(index, 1);
            this.saveBannedUsers();
            return true;
        }
        return false;
    }

    isBanned(phoneNumber) {
        const normalized = this._normalize(phoneNumber);
        if (!normalized) return false;
        return this.bannedUsers.includes(normalized);
    }

    getBannedUsers() {
        return [...this.bannedUsers];
    }
}

module.exports = DataManager;
