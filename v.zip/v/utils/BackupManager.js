/**
 * BackupManager - Automated database backup system
 * Creates compressed backups of the database and config files
 */
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const moment = require('moment');

class BackupManager {
    /**
     * @param {Object} config - Backup configuration
     * @param {Object} logger - Logger instance
     */
    constructor(config = {}, logger = null) {
        this.config = {
            enabled: config.enabled !== false,
            intervalHours: config.intervalHours || 24,
            keepCount: config.keepCount || 7,
            path: config.path || './backups'
        };
        this.logger = logger;
        this.backupInterval = null;

        this.ensureBackupDirectory();
    }

    /**
     * Ensure backup directory exists
     */
    ensureBackupDirectory() {
        if (!fs.existsSync(this.config.path)) {
            fs.mkdirSync(this.config.path, { recursive: true });
            this.log('info', `📁 Backup qovluğu yaradıldı: ${this.config.path}`);
        }
    }

    /**
     * Log message
     * @param {string} level - Log level
     * @param {string} message - Message
     * @param {Object} data - Additional data
     */
    log(level, message, data = null) {
        if (this.logger && this.logger[level]) {
            this.logger[level](message, data, 'system');
        } else {
            console.log(`[${level.toUpperCase()}] ${message}`);
        }
    }

    /**
     * Start automatic backup scheduler
     */
    start() {
        if (!this.config.enabled) {
            this.log('info', '⏸️ Avtomatik backup deaktivdir');
            return;
        }

        const intervalMs = this.config.intervalHours * 60 * 60 * 1000;

        this.backupInterval = setInterval(() => {
            this.createBackup();
        }, intervalMs);

        this.log('info', `💾 Avtomatik backup sistemi başladıldı (hər ${this.config.intervalHours} saat)`);

        // Create initial backup on start
        setTimeout(() => this.createBackup(), 5000);
    }

    /**
     * Stop automatic backup scheduler
     */
    stop() {
        if (this.backupInterval) {
            clearInterval(this.backupInterval);
            this.backupInterval = null;
            this.log('info', '⏹️ Avtomatik backup sistemi dayandırıldı');
        }
    }

    /**
     * Create a backup of the database and config files
     * @returns {Promise<string>} Path to created backup
     */
    async createBackup() {
        const timestamp = moment().format('YYYY-MM-DD_HH-mm-ss');
        const backupFileName = `backup_${timestamp}.zip`;
        const backupPath = path.join(this.config.path, backupFileName);

        const filesToBackup = [
            './tickets.db',
            './tickets.db-wal',
            './tickets.db-shm',
            './config.json',
            './admins.js',
            './bannedusers.json'
        ];

        try {
            await new Promise((resolve, reject) => {
                const output = fs.createWriteStream(backupPath);
                const archive = archiver('zip', { zlib: { level: 9 } });

                output.on('close', () => {
                    const sizeMB = (archive.pointer() / 1024 / 1024).toFixed(2);
                    this.log('info', `✅ Backup yaradıldı: ${backupFileName} (${sizeMB}MB)`, {
                        file: backupPath,
                        size: sizeMB
                    });
                    resolve();
                });

                output.on('error', reject);
                archive.on('error', reject);

                archive.pipe(output);

                // Add database and config files
                filesToBackup.forEach(file => {
                    if (fs.existsSync(file)) {
                        archive.file(file, { name: path.basename(file) });
                    }
                });

                // Add longphoto directory if exists
                if (fs.existsSync('./longphoto')) {
                    archive.directory('./longphoto', 'longphoto');
                }

                // Add logs directory
                if (fs.existsSync('./logs')) {
                    archive.directory('./logs', 'logs');
                }

                archive.finalize();
            });

            // Cleanup old backups
            await this.cleanupOldBackups();

            return backupPath;

        } catch (error) {
            this.log('error', '❌ Backup yaradılarkən xəta:', error);
            throw error;
        }
    }

    /**
     * Clean up old backups, keeping only the most recent N
     */
    async cleanupOldBackups() {
        try {
            const files = fs.readdirSync(this.config.path)
                .filter(f => f.startsWith('backup_') && f.endsWith('.zip'))
                .map(f => ({
                    name: f,
                    path: path.join(this.config.path, f),
                    time: fs.statSync(path.join(this.config.path, f)).mtime
                }))
                .sort((a, b) => b.time - a.time); // Newest first

            if (files.length > this.config.keepCount) {
                const toDelete = files.slice(this.config.keepCount);

                for (const file of toDelete) {
                    fs.unlinkSync(file.path);
                    this.log('info', `🗑️ Köhnə backup silindi: ${file.name}`);
                }
            }
        } catch (error) {
            this.log('error', '❌ Köhnə backuplar silinərkən xəta:', error);
        }
    }

    /**
     * Get list of available backups
     * @returns {Array} List of backup files
     */
    listBackups() {
        try {
            const files = fs.readdirSync(this.config.path)
                .filter(f => f.startsWith('backup_') && f.endsWith('.zip'))
                .map(f => {
                    const filePath = path.join(this.config.path, f);
                    const stats = fs.statSync(filePath);
                    return {
                        name: f,
                        path: filePath,
                        size: (stats.size / 1024 / 1024).toFixed(2) + 'MB',
                        created: moment(stats.mtime).format('DD.MM.YYYY HH:mm')
                    };
                })
                .sort((a, b) => b.name.localeCompare(a.name)); // Newest first

            return files;
        } catch (error) {
            this.log('error', '❌ Backup siyahısı alınarkən xəta:', error);
            return [];
        }
    }
}

module.exports = BackupManager;
