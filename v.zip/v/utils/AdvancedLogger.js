const fs = require('fs');
const path = require('path');
const moment = require('moment');

class AdvancedLogger {
    constructor(logsDir = './logs') {
        this.logsDir = logsDir;
        this.categories = ['info', 'warn', 'error', 'debug', 'performance', 'tickets', 'commands', 'photos', 'security'];
        this.ensureDirectories();
    }

    ensureDirectories() {
        this.categories.forEach(category => {
            const dir = path.join(this.logsDir, category);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        });
    }

    formatTimestamp() {
        return moment().format('YYYY-MM-DD HH:mm:ss');
    }

    getLogFilePath(category, date = moment().format('YYYY-MM-DD')) {
        return path.join(this.logsDir, category, `${date}.log`);
    }

    writeLog(category, level, message, data = null, timestamp = null) {
        if (!this.categories.includes(category)) {
            category = 'info';
        }

        const ts = timestamp || this.formatTimestamp();
        const logPath = this.getLogFilePath(category);
        
        let logEntry = `[${ts}] [${level}] ${message}`;
        if (data) {
            logEntry += `\n  Data: ${JSON.stringify(data, null, 2)}`;
        }
        logEntry += '\n';

        try {
            fs.appendFileSync(logPath, logEntry, 'utf8');
        } catch (error) {
            console.error(`❌ Log yazılarkən xəta (${category}):`, error);
        }
    }

    info(message, data = null, category = 'info') {
        console.log(`ℹ️  ${message}`);
        this.writeLog(category, 'INFO', message, data);
    }

    warn(message, data = null, category = 'warn') {
        console.log(`⚠️  ${message}`);
        this.writeLog(category, 'WARN', message, data);
    }

    error(message, error = null, category = 'error') {
        const errorMsg = error instanceof Error ? error.message : JSON.stringify(error);
        console.log(`❌ ${message}: ${errorMsg}`);
        this.writeLog(category, 'ERROR', message, { error: errorMsg });
    }

    debug(message, data = null, category = 'debug') {
        if (process.env.DEBUG === 'true') {
            console.log(`🔍 ${message}`);
            this.writeLog(category, 'DEBUG', message, data);
        }
    }

    ticket(message, data = null, category = 'tickets') {
        console.log(`🎫 ${message}`);
        this.writeLog(category, 'TICKET', message, data);
    }

    command(message, data = null, category = 'commands') {
        this.writeLog(category, 'COMMAND', message, data);
    }

    performance(message, data = null, category = 'performance') {
        this.writeLog(category, 'PERFORMANCE', message, data);
    }

    photo(message, data = null, category = 'photos') {
        console.log(`📸 ${message}`);
        this.writeLog(category, 'PHOTO', message, data);
    }

    security(message, data = null, category = 'security') {
        console.log(`🔒 ${message}`);
        this.writeLog(category, 'SECURITY', message, data);
    }

    async getLogStats() {
        const stats = {};
        
        try {
            for (const category of this.categories) {
                const logPath = this.getLogFilePath(category);
                if (fs.existsSync(logPath)) {
                    const content = fs.readFileSync(logPath, 'utf8');
                    stats[category] = (content.match(/\n/g) || []).length;
                } else {
                    stats[category] = 0;
                }
            }
        } catch (error) {
            console.error('❌ Log statistikaları gətirilərkən xəta:', error);
        }

        return stats;
    }

    clearOldLogs(daysToKeep = 7) {
        const cutoffDate = moment().subtract(daysToKeep, 'days');

        this.categories.forEach(category => {
            const dir = path.join(this.logsDir, category);
            try {
                const files = fs.readdirSync(dir);
                files.forEach(file => {
                    const dateMatch = file.match(/(\d{4}-\d{2}-\d{2})\.log/);
                    if (dateMatch) {
                        const fileDate = moment(dateMatch[1]);
                        if (fileDate.isBefore(cutoffDate)) {
                            fs.unlinkSync(path.join(dir, file));
                        }
                    }
                });
            } catch (error) {
                console.error(`❌ ${category} qovluğundaki qədim loglar silinərkən xəta:`, error);
            }
        });
    }
}

module.exports = AdvancedLogger;
