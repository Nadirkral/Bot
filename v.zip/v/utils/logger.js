const fs = require('fs');
const path = require('path');

class Logger {
    static log(action, userId, details) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            action,
            userId,
            details
        };

        const logDir = path.join(__dirname, '../logs');
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir);
        }

        const logFile = path.join(logDir, 'bot.log');
        fs.appendFileSync(logFile, JSON.stringify(logEntry) + '\n');
    }
}

module.exports = Logger;