class RateLimiter {
    constructor(config) {
        this.config = config.rateLimits || {
            perMinute: 1,
            perHour: 5,
            perDay: 20
        };
        this.userTickets = new Map(); // { phone: { minute: [...], hour: [...], day: [...] } }

        // Store limits for easy access
        this.limits = {
            minute: { max: this.config.perMinute },
            hour: { max: this.config.perHour },
            day: { max: this.config.perDay }
        };

        // Cleanup every hour - store reference for proper shutdown
        this.cleanupInterval = setInterval(() => this.cleanup(), 60 * 60 * 1000);
    }

    cleanup() {
        const now = Date.now();
        const oneDayAgo = now - 24 * 60 * 60 * 1000;
        let cleanedCount = 0;

        for (const [phone, record] of this.userTickets.entries()) {
            // Filter out old timestamps
            record.minute = record.minute.filter(t => t > now - 60 * 1000);
            record.hour = record.hour.filter(t => t > now - 60 * 60 * 1000);
            record.day = record.day.filter(t => t > oneDayAgo);

            // If no activity in the last 24 hours (empty day list), remove user
            if (record.day.length === 0) {
                this.userTickets.delete(phone);
                cleanedCount++;
            }
        }

        if (cleanedCount > 0) {
            console.log(`🧹 RateLimiter: ${cleanedCount} inactive users cleaned.`);
        }
    }

    recordTicketCreation(phone) {
        const now = Date.now();

        if (!this.userTickets.has(phone)) {
            this.userTickets.set(phone, {
                minute: [],
                hour: [],
                day: []
            });
        }

        const userRecord = this.userTickets.get(phone);
        userRecord.minute.push(now);
        userRecord.hour.push(now);
        userRecord.day.push(now);

        // Qədim zamanları sil
        const oneMinuteAgo = now - 60 * 1000;
        const oneHourAgo = now - 60 * 60 * 1000;
        const oneDayAgo = now - 24 * 60 * 60 * 1000;

        userRecord.minute = userRecord.minute.filter(t => t > oneMinuteAgo);
        userRecord.hour = userRecord.hour.filter(t => t > oneHourAgo);
        userRecord.day = userRecord.day.filter(t => t > oneDayAgo);
    }

    canCreateTicket(phone) {
        const now = Date.now();
        const oneMinuteAgo = now - 60 * 1000;
        const oneHourAgo = now - 60 * 60 * 1000;
        const oneDayAgo = now - 24 * 60 * 60 * 1000;

        if (!this.userTickets.has(phone)) {
            return { allowed: true };
        }

        const userRecord = this.userTickets.get(phone);

        // Dəqiqə limiti
        const minuteCount = userRecord.minute.filter(t => t > oneMinuteAgo).length;
        if (minuteCount >= this.config.perMinute) {
            const oldestMinute = Math.min(...userRecord.minute);
            const remainingTime = oldestMinute + 60 * 1000 - now;
            return {
                allowed: false,
                period: 'minute',
                currentCount: minuteCount,
                maxLimit: this.config.perMinute,
                remainingTime
            };
        }

        // Saat limiti
        const hourCount = userRecord.hour.filter(t => t > oneHourAgo).length;
        if (hourCount >= this.config.perHour) {
            const oldestHour = Math.min(...userRecord.hour);
            const remainingTime = oldestHour + 60 * 60 * 1000 - now;
            return {
                allowed: false,
                period: 'hour',
                currentCount: hourCount,
                maxLimit: this.config.perHour,
                remainingTime
            };
        }

        // Gün limiti
        const dayCount = userRecord.day.filter(t => t > oneDayAgo).length;
        if (dayCount >= this.config.perDay) {
            return {
                allowed: false,
                period: 'day',
                currentCount: dayCount,
                maxLimit: this.config.perDay
            };
        }

        return {
            allowed: true,
            currentCount: Math.max(minuteCount, hourCount, dayCount)
        };
    }

    formatRemainingTime(milliseconds) {
        const seconds = Math.ceil(milliseconds / 1000);
        if (seconds < 60) {
            return `${seconds} saniyə`;
        } else if (seconds < 3600) {
            const minutes = Math.ceil(seconds / 60);
            return `${minutes} dəqiqə`;
        } else {
            const hours = Math.ceil(seconds / 3600);
            return `${hours} saat`;
        }
    }

    getStats(phone) {
        const now = Date.now();
        const oneMinuteAgo = now - 60 * 1000;
        const oneHourAgo = now - 60 * 60 * 1000;
        const oneDayAgo = now - 24 * 60 * 60 * 1000;

        if (!this.userTickets.has(phone)) {
            return {
                minute: 0,
                hour: 0,
                day: 0
            };
        }

        const userRecord = this.userTickets.get(phone);

        return {
            minute: userRecord.minute.filter(t => t > oneMinuteAgo).length,
            hour: userRecord.hour.filter(t => t > oneHourAgo).length,
            day: userRecord.day.filter(t => t > oneDayAgo).length,
            limits: this.config
        };
    }

    // Alias method expected by bot.js handleRateLimitStats
    getUserStats(phone) {
        const now = Date.now();
        const oneMinuteAgo = now - 60 * 1000;
        const oneHourAgo = now - 60 * 60 * 1000;
        const oneDayAgo = now - 24 * 60 * 60 * 1000;

        if (!this.userTickets.has(phone)) {
            return null;
        }

        const userRecord = this.userTickets.get(phone);

        // Calculate reset times (when the oldest entry expires)
        const minuteResetTime = userRecord.minute.length > 0
            ? Math.min(...userRecord.minute) + 60 * 1000
            : now;
        const hourResetTime = userRecord.hour.length > 0
            ? Math.min(...userRecord.hour) + 60 * 60 * 1000
            : now;
        const dayResetTime = userRecord.day.length > 0
            ? Math.min(...userRecord.day) + 24 * 60 * 60 * 1000
            : now;

        return {
            minute: {
                count: userRecord.minute.filter(t => t > oneMinuteAgo).length,
                resetTime: minuteResetTime
            },
            hour: {
                count: userRecord.hour.filter(t => t > oneHourAgo).length,
                resetTime: hourResetTime
            },
            day: {
                count: userRecord.day.filter(t => t > oneDayAgo).length,
                resetTime: dayResetTime
            }
        };
    }

    resetUser(phone) {
        this.userTickets.delete(phone);
    }

    resetAll() {
        this.userTickets.clear();
    }
}

module.exports = RateLimiter;
