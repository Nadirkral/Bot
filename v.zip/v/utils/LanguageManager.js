/**
 * LanguageManager - Multi-language support for the bot
 * Supports: Azerbaijani (az), Russian (ru), English (en)
 */
const fs = require('fs');
const path = require('path');

class LanguageManager {
    constructor(db = null, localesDir = './locales') {
        this.db = db;
        this.localesDir = localesDir;
        this.languages = {};
        this.defaultLang = 'az';
        this.supportedLangs = ['az', 'ru', 'en'];
        this.userLangCache = new Map();

        this.loadLanguages();
    }

    /**
     * Load all language files
     */
    loadLanguages() {
        // Ensure locales directory exists
        if (!fs.existsSync(this.localesDir)) {
            fs.mkdirSync(this.localesDir, { recursive: true });
        }

        for (const lang of this.supportedLangs) {
            const filePath = path.join(this.localesDir, `${lang}.json`);
            try {
                if (fs.existsSync(filePath)) {
                    const data = fs.readFileSync(filePath, 'utf8');
                    this.languages[lang] = JSON.parse(data);
                } else {
                    console.log(`⚠️ Language file not found: ${filePath}`);
                    this.languages[lang] = {};
                }
            } catch (error) {
                console.error(`❌ Error loading language ${lang}:`, error);
                this.languages[lang] = {};
            }
        }

        console.log(`✅ Languages loaded: ${Object.keys(this.languages).join(', ')}`);
    }

    /**
     * Get translated string
     * @param {string} userPhone - User phone for language preference
     * @param {string} key - Translation key
     * @param {Object} params - Parameters to replace in string
     * @returns {string}
     */
    async get(userPhone, key, params = {}) {
        const lang = await this.getUserLang(userPhone);
        return this.translate(lang, key, params);
    }

    /**
     * Get translated string (sync version using cache)
     * @param {string} userPhone - User phone
     * @param {string} key - Translation key
     * @param {Object} params - Parameters
     * @returns {string}
     */
    getSync(userPhone, key, params = {}) {
        const lang = this.userLangCache.get(userPhone) || this.defaultLang;
        return this.translate(lang, key, params);
    }

    /**
     * Translate a key to a specific language
     * @param {string} lang - Language code
     * @param {string} key - Translation key
     * @param {Object} params - Parameters
     * @returns {string}
     */
    translate(lang, key, params = {}) {
        let text = this.languages[lang]?.[key]
            || this.languages[this.defaultLang]?.[key]
            || key;

        // Replace parameters like {name}, {id}, etc.
        for (const [param, value] of Object.entries(params)) {
            text = text.replace(new RegExp(`{${param}}`, 'g'), value);
        }

        return text;
    }

    /**
     * Get user's language preference
     * @param {string} userPhone - User phone
     * @returns {Promise<string>}
     */
    async getUserLang(userPhone) {
        // Check cache first
        if (this.userLangCache.has(userPhone)) {
            return this.userLangCache.get(userPhone);
        }

        // Check database
        if (this.db) {
            try {
                const row = await this.db.get(
                    'SELECT language FROM user_preferences WHERE user_id = ?',
                    [userPhone]
                );
                if (row && row.language) {
                    this.userLangCache.set(userPhone, row.language);
                    return row.language;
                }
            } catch (error) {
                // Table might not exist yet
            }
        }

        return this.defaultLang;
    }

    /**
     * Set user's language preference
     * @param {string} userPhone - User phone
     * @param {string} lang - Language code
     * @returns {Promise<boolean>}
     */
    async setUserLang(userPhone, lang) {
        if (!this.supportedLangs.includes(lang)) {
            return false;
        }

        this.userLangCache.set(userPhone, lang);

        if (this.db) {
            try {
                await this.db.run(
                    `INSERT OR REPLACE INTO user_preferences (user_id, language) VALUES (?, ?)`,
                    [userPhone, lang]
                );
            } catch (error) {
                console.error('❌ Error saving language preference:', error);
            }
        }

        return true;
    }

    /**
     * Get language name in its own language
     * @param {string} lang - Language code
     * @returns {string}
     */
    getLangName(lang) {
        const names = {
            'az': '🇦🇿 Azərbaycan',
            'ru': '🇷🇺 Русский',
            'en': '🇬🇧 English'
        };
        return names[lang] || lang;
    }

    /**
     * Get all supported languages
     * @returns {Array}
     */
    getSupportedLangs() {
        return this.supportedLangs.map(lang => ({
            code: lang,
            name: this.getLangName(lang)
        }));
    }
}

module.exports = LanguageManager;
