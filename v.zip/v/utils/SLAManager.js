/**
 * SLAManager - Service Level Agreement tracking for tickets
 * Monitors ticket age and sends escalation alerts
 */
const moment = require('moment');

class SLAManager {
    /**
     * @param {Object} config - SLA configuration
     * @param {Object} db - Database instance
     * @param {Object} logger - Logger instance
     */
    constructor(config = {}, db = null, logger = null) {
        this.config = {
            warningHours: config.warningHours || 2,
            criticalHours: config.criticalHours || 4,
            enableEscalation: config.enableEscalation !== false
        };
        this.db = db;
        this.logger = logger;
        this.checkInterval = null;
    }

    /**
     * Log message
     * @param {string} level - Log level
     * @param {string} message - Message
     * @param {Object} data - Additional data
     */
    log(level, message, data = null) {
        if (this.logger && this.logger[level]) {
            this.logger[level](message, data, 'system');
        } else {
            console.log(`[${level.toUpperCase()}] ${message}`);
        }
    }

    /**
     * Start SLA monitoring (checks every 15 minutes)
     * @param {Function} sendAlert - Function to send alerts
     */
    start(sendAlert) {
        this.sendAlert = sendAlert;

        // Check every 15 minutes
        this.checkInterval = setInterval(() => {
            this.checkSLAViolations();
        }, 15 * 60 * 1000);

        this.log('info', `⏱️ SLA monitoring başladıldı (warning: ${this.config.warningHours}h, critical: ${this.config.criticalHours}h)`);
    }

    /**
     * Stop SLA monitoring
     */
    stop() {
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
            this.checkInterval = null;
            this.log('info', '⏹️ SLA monitoring dayandırıldı');
        }
    }

    /**
     * Calculate ticket age in hours
     * @param {string} createdAt - Creation timestamp
     * @returns {number} Age in hours
     */
    getTicketAgeHours(createdAt) {
        const created = moment(createdAt);
        const now = moment();
        return now.diff(created, 'hours', true);
    }

    /**
     * Get SLA status for a ticket
     * @param {Object} ticket - Ticket object
     * @returns {Object} SLA status
     */
    getTicketSLAStatus(ticket) {
        const ageHours = this.getTicketAgeHours(ticket.created_at);

        let status = 'ok';
        let emoji = '🟢';
        let message = 'Normal';

        if (ageHours >= this.config.criticalHours) {
            status = 'critical';
            emoji = '🔴';
            message = `Kritik (${ageHours.toFixed(1)} saat)`;
        } else if (ageHours >= this.config.warningHours) {
            status = 'warning';
            emoji = '🟡';
            message = `Xəbərdarlıq (${ageHours.toFixed(1)} saat)`;
        } else {
            message = `Normal (${ageHours.toFixed(1)} saat)`;
        }

        return {
            status,
            emoji,
            message,
            ageHours: ageHours.toFixed(1),
            ticket
        };
    }

    /**
     * Check all open tickets for SLA violations
     */
    async checkSLAViolations() {
        if (!this.db) return;

        try {
            const openTickets = await this.db.all(
                "SELECT * FROM tickets WHERE status = 'open' ORDER BY created_at ASC"
            );

            const violations = {
                warning: [],
                critical: []
            };

            for (const ticket of openTickets) {
                const sla = this.getTicketSLAStatus(ticket);

                if (sla.status === 'critical') {
                    violations.critical.push(sla);
                } else if (sla.status === 'warning') {
                    violations.warning.push(sla);
                }
            }

            // Send escalation if enabled and we have critical violations
            if (this.config.enableEscalation && violations.critical.length > 0 && this.sendAlert) {
                await this.sendEscalationAlert(violations);
            }

            return violations;

        } catch (error) {
            this.log('error', '❌ SLA yoxlanışı xətası:', error);
            return null;
        }
    }

    /**
     * Send escalation alert for critical tickets
     * @param {Object} violations - Violation data
     */
    async sendEscalationAlert(violations) {
        if (!this.sendAlert) return;

        let alertMessage = `🚨 SLA ESKALASİYASI\n\n`;

        if (violations.critical.length > 0) {
            alertMessage += `🔴 KRİTİK (>${this.config.criticalHours} saat):\n`;
            violations.critical.forEach(v => {
                alertMessage += `• #${v.ticket.id} - K${v.ticket.corpus}-${v.ticket.room}\n`;
                alertMessage += `  ${v.ticket.problem_type}\n`;
                alertMessage += `  ⏰ ${v.ageHours} saat əvvəl açıldı\n\n`;
            });
        }

        if (violations.warning.length > 0) {
            alertMessage += `🟡 XƏBƏRDARLIQ (>${this.config.warningHours} saat):\n`;
            violations.warning.forEach(v => {
                alertMessage += `• #${v.ticket.id} - K${v.ticket.corpus}-${v.ticket.room} (${v.ageHours}h)\n`;
            });
        }

        alertMessage += `\n⚠️ Zəhmət olmasa həll edin!`;

        try {
            await this.sendAlert(alertMessage);
            this.log('warn', '🚨 SLA eskalasiya göndərildi', {
                critical: violations.critical.length,
                warning: violations.warning.length
            });
        } catch (error) {
            this.log('error', '❌ SLA eskalasiya göndərilə bilmədi:', error);
        }
    }

    /**
     * Get full SLA report for all open tickets
     * @returns {Promise<Object>} SLA report
     */
    async getSLAReport() {
        if (!this.db) return null;

        try {
            const openTickets = await this.db.all(
                "SELECT * FROM tickets WHERE status = 'open' ORDER BY created_at ASC"
            );

            const report = {
                total: openTickets.length,
                ok: [],
                warning: [],
                critical: [],
                stats: {
                    avgAgeHours: 0,
                    oldestHours: 0
                }
            };

            let totalAge = 0;

            for (const ticket of openTickets) {
                const sla = this.getTicketSLAStatus(ticket);
                totalAge += parseFloat(sla.ageHours);

                if (sla.status === 'critical') {
                    report.critical.push(sla);
                } else if (sla.status === 'warning') {
                    report.warning.push(sla);
                } else {
                    report.ok.push(sla);
                }

                if (parseFloat(sla.ageHours) > report.stats.oldestHours) {
                    report.stats.oldestHours = parseFloat(sla.ageHours);
                }
            }

            if (openTickets.length > 0) {
                report.stats.avgAgeHours = (totalAge / openTickets.length).toFixed(1);
            }

            return report;

        } catch (error) {
            this.log('error', '❌ SLA hesabatı xətası:', error);
            return null;
        }
    }
}

module.exports = SLAManager;
