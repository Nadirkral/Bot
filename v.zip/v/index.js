const ADNSUITBot = require('./bot');

// Botu başlat
const bot = new ADNSUITBot();
bot.initialize();

// Əlaqəni qorumaq üçün
process.on('unhandledRejection', (error) => {
    console.error('Unhandled rejection:', error);
});

process.on('uncaughtException', (error) => {
    console.error('Uncaught exception:', error);
});