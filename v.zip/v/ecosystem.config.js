module.exports = {
    apps: [{
        name: 'adnsu-it-bot',
        script: './bot.js',

        // ============================================================================
        // AUTO-RESTART CONFIGURATION
        // ============================================================================
        instances: 1,
        autorestart: true,
        watch: false,
        max_memory_restart: '500M', // Restart if memory exceeds 500MB

        // Restart delay after crash
        restart_delay: 3000, // 3 seconds

        // Max restarts within min_uptime before considering app as unstable
        max_restarts: 10,
        min_uptime: '10s',

        // ============================================================================
        // ERROR HANDLING
        // ============================================================================
        // Stop app after 10 restarts in 1 minute (prevents restart loop)
        exp_backoff_restart_delay: 100,

        // Kill timeout
        kill_timeout: 5000,

        // ============================================================================
        // LOGGING
        // ============================================================================
        error_file: './logs/pm2/error.log',
        out_file: './logs/pm2/out.log',
        log_date_format: 'YYYY-MM-DD HH:mm:ss Z',

        // Log rotation
        log_type: 'json',
        merge_logs: true,

        // ============================================================================
        // ENVIRONMENT
        // ============================================================================
        env: {
            NODE_ENV: 'production',
            TZ: 'Asia/Baku'
        },

        // ============================================================================
        // ADVANCED OPTIONS
        // ============================================================================
        // Listen for 'ready' event from app
        wait_ready: false,

        // Graceful shutdown
        listen_timeout: 10000,
        shutdown_with_message: false
    }]
};
