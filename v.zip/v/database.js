const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

/**
 * Database class for managing SQLite operations
 * Handles tickets, banned users, long photos, and admin profiles
 */
class Database {
    /**
     * Create a new Database instance
     * @param {string} dbPath - Path to the SQLite database file
     */
    constructor(dbPath = 'tickets.db') {
        this.dbPath = dbPath;
        this.db = null;
    }

    /**
     * Initialize the database connection and create tables
     * @returns {Promise<void>}
     */
    async init() {
        return new Promise((resolve, reject) => {
            this.db = new sqlite3.Database(this.dbPath, async (err) => {
                if (err) {
                    console.error('❌ Database error:', err);
                    reject(err);
                } else {
                    console.log('✅ Database connected');

                    try {
                        // Enable WAL mode for better concurrency
                        await this.run("PRAGMA journal_mode = WAL;");
                        console.log("✅ WAL mode enabled");

                        // Set busy timeout to wait for locks
                        await this.run("PRAGMA busy_timeout = 5000;");

                        // Create tables and indexes
                        await this.createTables();
                        await this.createIndexes();
                        await this.runMigrations();

                        resolve();
                    } catch (initError) {
                        console.error('❌ Database initialization error:', initError);
                        reject(initError);
                    }
                }
            });
        });
    }

    /**
     * Create all required database tables
     * @returns {Promise<void>}
     */
    async createTables() {
        const ticketsTable = `
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                username TEXT,
                phone TEXT,
                corpus TEXT,
                room TEXT,
                problem_type TEXT,
                problem_description TEXT,
                priority TEXT DEFAULT 'normal',
                status TEXT DEFAULT 'open',
                assigned_admin TEXT,
                assigned_admin_name TEXT,
                solution TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                solved_at DATETIME,
                solved_by_phone TEXT,
                notes TEXT
            )
        `;

        const bannedUsersTable = `
            CREATE TABLE IF NOT EXISTS banned_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT UNIQUE NOT NULL,
                reason TEXT,
                banned_by TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `;

        const longPhotosTable = `
            CREATE TABLE IF NOT EXISTS long_photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                fileName TEXT,
                uploadedBy TEXT,
                uploadTime DATETIME,
                fileSize TEXT,
                uploadTimestamp LONG,
                mimetype TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(ticket_id) REFERENCES tickets(id)
            )
        `;

        const adminProfilesTable = `
            CREATE TABLE IF NOT EXISTS admin_profiles (
                phone TEXT PRIMARY KEY,
                name TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `;

        const ticketHistoryTable = `
            CREATE TABLE IF NOT EXISTS ticket_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                old_value TEXT,
                new_value TEXT,
                changed_by TEXT,
                changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(ticket_id) REFERENCES tickets(id)
            )
        `;

        const feedbackTable = `
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL UNIQUE,
                user_phone TEXT,
                rating INTEGER CHECK(rating >= 1 AND rating <= 5),
                comment TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(ticket_id) REFERENCES tickets(id)
            )
        `;

        const adminMetricsTable = `
            CREATE TABLE IF NOT EXISTS admin_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_phone TEXT NOT NULL,
                ticket_id INTEGER NOT NULL,
                assigned_at DATETIME,
                solved_at DATETIME,
                response_time_minutes INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(ticket_id) REFERENCES tickets(id)
            )
        `;

        const userPreferencesTable = `
            CREATE TABLE IF NOT EXISTS user_preferences (
                user_id TEXT PRIMARY KEY,
                language TEXT DEFAULT 'az',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `;
        const adminSessionsTable = `
            CREATE TABLE IF NOT EXISTS admin_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_phone TEXT NOT NULL,
                token_hash TEXT NOT NULL,
                ip_address TEXT,
                user_agent TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME,
                is_active INTEGER DEFAULT 1
            )
        `;

        const securityLogsTable = `
            CREATE TABLE IF NOT EXISTS security_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                details TEXT,
                ip_address TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `;

        const adminPasswordsTable = `
            CREATE TABLE IF NOT EXISTS admin_passwords (
                phone TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL,
                must_change INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `;

        await this.run(ticketsTable);
        await this.run(bannedUsersTable);
        await this.run(longPhotosTable);
        await this.run(adminProfilesTable);
        await this.run(ticketHistoryTable);
        await this.run(feedbackTable);
        await this.run(adminMetricsTable);
        await this.run(userPreferencesTable);
        await this.run(adminSessionsTable);
        await this.run(securityLogsTable);
        await this.run(adminPasswordsTable);

        console.log('✅ All tables created/verified');
    }

    /**
     * Create database indexes for better query performance
     * @returns {Promise<void>}
     */
    async createIndexes() {
        const indexes = [
            'CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status)',
            'CREATE INDEX IF NOT EXISTS idx_tickets_created_at ON tickets(created_at)',
            'CREATE INDEX IF NOT EXISTS idx_tickets_assigned_admin ON tickets(assigned_admin)',
            'CREATE INDEX IF NOT EXISTS idx_tickets_corpus_room ON tickets(corpus, room)',
            'CREATE INDEX IF NOT EXISTS idx_tickets_priority ON tickets(priority)',
            'CREATE INDEX IF NOT EXISTS idx_long_photos_ticket_id ON long_photos(ticket_id)',
            'CREATE INDEX IF NOT EXISTS idx_ticket_history_ticket_id ON ticket_history(ticket_id)',
            'CREATE INDEX IF NOT EXISTS idx_banned_users_user_id ON banned_users(user_id)'
        ];

        for (const indexSql of indexes) {
            try {
                await this.run(indexSql);
            } catch (err) {
                // Index might already exist, ignore errors
                console.log('Index creation note:', err.message);
            }
        }

        console.log('✅ Database indexes created/verified');
    }

    /**
     * Run database migrations for schema updates
     * @returns {Promise<void>}
     */
    async runMigrations() {
        try {
            const columns = await this.all("PRAGMA table_info(tickets)");
            const columnNames = columns.map(c => c.name);

            // Add phone column if missing
            if (!columnNames.includes('phone')) {
                console.log('⚠️ Phone column missing, adding it...');
                await this.run("ALTER TABLE tickets ADD COLUMN phone TEXT");
                console.log('✅ Phone column added');
            }

            // Add solved_by_phone column if missing
            if (!columnNames.includes('solved_by_phone')) {
                console.log('⚠️ solved_by_phone column missing, adding it...');
                await this.run("ALTER TABLE tickets ADD COLUMN solved_by_phone TEXT");
                console.log('✅ solved_by_phone column added');
            }

            // Add assigned_admin_name column if missing
            if (!columnNames.includes('assigned_admin_name')) {
                console.log('⚠️ assigned_admin_name column missing, adding it...');
                await this.run("ALTER TABLE tickets ADD COLUMN assigned_admin_name TEXT");
                console.log('✅ assigned_admin_name column added');
            }

            // Add priority column if missing
            if (!columnNames.includes('priority')) {
                console.log('⚠️ priority column missing, adding it...');
                await this.run("ALTER TABLE tickets ADD COLUMN priority TEXT DEFAULT 'normal'");
                console.log('✅ priority column added');
            }

            // Add must_change column to admin_passwords if missing
            try {
                const pwColumns = await this.all("PRAGMA table_info(admin_passwords)");
                const pwColumnNames = pwColumns.map(c => c.name);
                if (!pwColumnNames.includes('must_change')) {
                    console.log('⚠️ must_change column missing in admin_passwords, adding it...');
                    await this.run("ALTER TABLE admin_passwords ADD COLUMN must_change INTEGER DEFAULT 0");
                    console.log('✅ must_change column added');
                }
            } catch (e) {
                // Table might not exist yet
            }

            console.log('✅ Migrations completed');
        } catch (err) {
            console.error('❌ Migration error:', err);
        }
    }

    /**
     * Log a ticket history entry
     * @param {number} ticketId - Ticket ID
     * @param {string} action - Action performed (created, status_changed, assigned, solved, etc.)
     * @param {string} oldValue - Previous value
     * @param {string} newValue - New value
     * @param {string} changedBy - Who made the change
     * @returns {Promise<Object>}
     */
    async logHistory(ticketId, action, oldValue, newValue, changedBy) {
        return this.run(
            `INSERT INTO ticket_history (ticket_id, action, old_value, new_value, changed_by) VALUES (?, ?, ?, ?, ?)`,
            [ticketId, action, oldValue, newValue, changedBy]
        );
    }

    /**
     * Get ticket history
     * @param {number} ticketId - Ticket ID
     * @returns {Promise<Array>}
     */
    async getHistory(ticketId) {
        return this.all(
            `SELECT * FROM ticket_history WHERE ticket_id = ? ORDER BY changed_at DESC`,
            [ticketId]
        );
    }

    /**
     * Execute a SQL statement that modifies data
     * @param {string} sql - SQL query
     * @param {Array} params - Query parameters
     * @returns {Promise<Object>} Object with lastID and changes
     */
    run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function (err) {
                if (err) reject(err);
                else resolve({ id: this.lastID, changes: this.changes });
            });
        });
    }

    /**
     * Get a single row from the database
     * @param {string} sql - SQL query
     * @param {Array} params - Query parameters
     * @returns {Promise<Object|undefined>}
     */
    get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    /**
     * Get multiple rows from the database
     * @param {string} sql - SQL query
     * @param {Array} params - Query parameters
     * @returns {Promise<Array>}
     */
    all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }

    /**
     * Close the database connection
     * @returns {Promise<void>}
     */
    close() {
        return new Promise((resolve, reject) => {
            if (this.db) {
                this.db.close((err) => {
                    if (err) reject(err);
                    else {
                        console.log('✅ Database connection closed');
                        resolve();
                    }
                });
            } else {
                resolve();
            }
        });
    }
}

module.exports = Database;