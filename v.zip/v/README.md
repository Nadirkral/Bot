# ADNSU IT Bot - Hərtərəfli Sənədləşmə

ADNSU IT departamentinin WhatsApp əsaslı ticket dəstək sistemi.

## Quraşdırma

### Tələblər
- Node.js 16+
- npm

### Addımlar

1. **Asılılıqları quraşdırın:**
```bash
npm install
```

2. **Konfiqurasiyanı tənzimləyin:**
`config.json` faylını redaktə edin:
```json
{
  "adminCredentials": {
    "username": "your_username",
    "password": "your_password"
  },
  "traineeGroupId": "",
  "dashboardPort": 3000,
  "sla": {
    "warningHours": 2,
    "criticalHours": 4
  },
  "backup": {
    "enabled": true,
    "intervalHours": 24
  }
}
```

3. **Botu başladın:**
```bash
npm start
```

4. **QR kodu skan edin** WhatsApp-da

## Əmrlər

### 🎫 Ticket İdarəetmə
| Əmr | Təsvir |
|-----|--------|
| `/list` | Açıq ticketları göstər |
| `/long list` | Uzunmüddətli ticketlar |
| `/solved <id> <həll>` | Ticket həll et |
| `/long <id>` | Uzunmüddətli et |
| `/unsolved <id>` | Yenidən aç |
| `/assign <id>` | Özünə götür |
| `/noassign <id>` | İmtina et |
| `/priority <id> <səviyyə>` | Prioritet dəyiş |
| `/history <id>` | Tarixçəni göstər |
| `/find <söz>` | Ticket axtar |
| `/search <söz>` | Ətraflı axtarış |

### ⏱️ SLA & Performans
| Əmr | Təsvir |
|-----|--------|
| `/sla` | SLA hesabatı |
| `/adminperformance` | Admin performansı |
| `/rate <id> <1-5>` | Ticket qiymətləndir |

### 💾 Backup (Admin)
| Əmr | Təsvir |
|-----|--------|
| `/backup` | Manual backup yarat |

### 📊 Prioritet Səviyyələri
- `low` - 🟢 Aşağı
- `normal` - 🟡 Normal (standart)
- `high` - 🟠 Yüksək
- `urgent` - 🔴 Təcili

### 👮 Admin Əmrləri (yalnız şəxsi mesaj)
| Əmr | Təsvir |
|-----|--------|
| `/login` | Admin giriş |
| `/logout` | Admin çıxış |
| `/ban <nömrə>` | İstifadəçini banla |
| `/unban <nömrə>` | Banı aç |
| `/listban` | Ban siyahısı |
| `/admin add <nömrə>` | Admin əlavə et |
| `/admin remove <nömrə>` | Admin sil |
| `/admin list` | Admin siyahısı |
| `/register <ad>` | Adını qeyd et |

### 📤 Export Əmrləri (yalnız şəxsi mesaj)
| Əmr | Təsvir |
|-----|--------|
| `/export` | Excel və PDF export |
| `/logexport` | Log faylları ZIP |
| `/databaseexport` | Database backup |

### 📊 Statistika
| Əmr | Təsvir |
|-----|--------|
| `/stats` | Ümumi statistika |
| `/today` | Bugünkü ticketlar |
| `/ping` | Bot statusu |

## Avtomatik Xüsusiyyətlər

### 💾 Avtomatik Backup
- Hər 24 saatda avtomatik backup
- Son 7 backup saxlanılır
- `./backups` qovluğunda

### ⏱️ SLA Monitoring
- Ticketlar 2+ saat açıq qaldıqda xəbərdarlıq
- 4+ saat ərzində kritik eskalasiya
- Hər 15 dəqiqədə yoxlanılır

### ⏰ Avtomatik Xatırlatma
- İş günləri: Bazar ertəsi - Cümə
- İş saatları: 08:00 - 22:00
- Hər 5 dəqiqədə açıq ticketlar

## Dashboard

Real-time ticket dashboard: `http://localhost:3000/tickets.html`

## Fayl Strukturu

```
├── bot.js              # Əsas bot faylı
├── database.js         # SQLite database
├── dashboard_server.js # Express dashboard
├── config.json         # Konfiqurasiya
├── handlers/           # Əmr handlerləri
├── utils/
│   ├── BackupManager.js  # Backup sistemi
│   ├── SLAManager.js     # SLA monitoring
│   └── ...
└── public/             # Dashboard UI
```

## Lisenziya
ADNSU IT departamenti üçün hazırlanmışdır.
