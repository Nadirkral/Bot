# ADNSU IT Bot - Stability & Crash Prevention Guide

## 🚀 Quick Start with PM2 (Recommended)

PM2 avtomatik olaraq bot-u yenidən başladır əgər crash olarsa.

### Installation

```bash
# Install PM2 globally
npm install -g pm2

# Install project dependencies (including PM2 locally)
npm install
```

### Running the Bot

```bash
# Start bot with PM2
npm run pm2:start

# View logs
npm run pm2:logs

# Monitor bot (CPU, memory, etc.)
npm run pm2:monit

# Check status
npm run pm2:status

# Restart bot
npm run pm2:restart

# Stop bot
npm run pm2:stop
```

### PM2 Auto-Restart on System Reboot

```bash
# Save PM2 process list
pm2 save

# Generate startup script
pm2 startup

# Follow the instructions shown
```

---

## ✅ Implemented Stability Features

### 1. Global Error Handlers ✅
- `process.on('unhandledRejection')` - Catches all unhandled promise rejections
- `process.on('uncaughtException')` - Catches all uncaught exceptions
- Bot continues running even after errors

### 2. WhatsApp Connection Recovery ✅
- `client.on('auth_failure')` - Handles authentication failures
- `client.on('disconnected')` - Auto-reconnects after 5 seconds
- `client.on('loading_screen')` - Monitors connection status

### 3. Event Handler Protection ✅
- All event handlers wrapped in try/catch
- Errors logged but don't crash the bot
- User-friendly error messages sent to users

### 4. Database Safety ✅
- WAL mode enabled for better concurrency
- Busy timeout set to 5 seconds
- Atomic file writes for JSON data

### 5. Stream Error Handling ✅
- PDF generation has error handlers
- Excel export has error handlers
- ZIP archive operations have error handlers

### 6. Memory Management ✅
- RateLimiter cleanup runs every hour
- Inactive users removed after 24 hours
- Temporary files deleted after sending

### 7. PM2 Process Management ✅
- Auto-restart on crash (3 second delay)
- Memory limit: 500MB (auto-restart if exceeded)
- Log rotation enabled
- Max 10 restarts in 1 minute (prevents restart loops)

---

## 🔧 Troubleshooting

### Bot Crashes Immediately

1. **Check logs:**
   ```bash
   npm run pm2:logs
   ```

2. **Check for missing modules:**
   ```bash
   npm install
   ```

3. **Check database:**
   - Ensure `tickets.db` is not corrupted
   - Delete `.wwebjs_auth` folder and re-scan QR code

### WhatsApp Session Issues

```bash
# Delete session folder
rm -rf .wwebjs_auth

# Restart bot
npm run pm2:restart

# Scan QR code again
npm run pm2:logs
```

### High Memory Usage

```bash
# Check memory
npm run pm2:monit

# Restart bot to clear memory
npm run pm2:restart
```

### Database Locked Error

- WAL mode is already enabled
- If persists, check for other processes accessing the database
- Restart the bot

---

## 📊 Monitoring

### View Real-Time Logs
```bash
npm run pm2:logs
```

### View Bot Status
```bash
npm run pm2:status
```

### Monitor CPU & Memory
```bash
npm run pm2:monit
```

---

## 🛡️ Security Best Practices

1. **Change default admin credentials** in `config.json`
2. **Keep logs directory** under 1GB (auto-cleanup runs weekly)
3. **Backup database** regularly:
   ```bash
   # Use /databaseexport command in WhatsApp
   ```

---

## 📝 Log Files

- **System logs:** `./logs/info/`, `./logs/error/`
- **Security logs:** `./logs/security/`
- **Command logs:** `./logs/commands/`
- **PM2 logs:** `./logs/pm2/`

---

## 🔄 Update Bot

```bash
# Stop bot
npm run pm2:stop

# Pull latest changes (if using git)
git pull

# Install dependencies
npm install

# Start bot
npm run pm2:start
```

---

## ⚠️ Common Crash Causes (FIXED)

| Issue | Status | Solution |
|-------|--------|----------|
| Unhandled promise rejections | ✅ FIXED | Global error handlers added |
| WhatsApp disconnection | ✅ FIXED | Auto-reconnect after 5s |
| Stream errors (PDF/Excel/ZIP) | ✅ FIXED | Error handlers on all streams |
| Database locked | ✅ FIXED | WAL mode + busy timeout |
| Memory leaks | ✅ FIXED | Cleanup intervals + PM2 memory limit |
| Missing modules | ✅ FIXED | All modules in package.json |
| Event handler crashes | ✅ FIXED | Try/catch wrappers |
| Process not restarting | ✅ FIXED | PM2 auto-restart |

---

## 📞 Support

If bot continues to crash:
1. Check `./logs/error/` for error details
2. Check `./logs/pm2/error.log` for PM2 errors
3. Run `npm run pm2:logs` to see real-time logs
